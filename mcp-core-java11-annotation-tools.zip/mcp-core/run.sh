#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GSON_PATH="${GSON_PATH:-/opt/advent/sdk/2.2.50.0/gw_javacots.4.0.80.c2a7e16231/lib/gson-2.8.0.jar}"
JAR_PATH="$PROJECT_DIR/out/mcp-core.jar"

if [[ ! -f "$JAR_PATH" ]]; then
  echo "Build output not found. Run ./build.sh first." >&2
  exit 1
fi
if [[ ! -f "$GSON_PATH" ]]; then
  echo "Gson jar not found: $GSON_PATH" >&2
  exit 1
fi

exec java -cp "$JAR_PATH:$GSON_PATH" com.company.mcp.Main
