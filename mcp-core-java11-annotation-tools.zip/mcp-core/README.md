# mcp-core

Java 11-compatible MCP server using stdio and Gson 2.8.0.

## Adding a tool

Write a normal Java method and annotate it:

```java
public final class TextTools {
    @McpTool(name = "reverse_text", description = "Reverses the given text")
    public String reverseText(
            @McpParam(name = "text", description = "Text to reverse") String text) {
        return new StringBuilder(text).reverse().toString();
    }
}
```

Then register its object once in `Main`:

```java
registry.register(new TextTools());
```

The framework automatically:

- discovers every `@McpTool` method in the object,
- generates the MCP input schema,
- converts JSON arguments to Java values,
- invokes the method,
- converts its return value to an MCP response.

Supported input/output types in this version:

- `String`
- `boolean` / `Boolean`
- `byte`, `short`, `int`, `long` and wrappers
- `float`, `double` and wrappers
- `char` / `Character`
- `void` return values

Use `@McpParam(defaultValue = "30", required = false)` for optional primitive/String parameters.
Parameter names can be read from `@McpParam(name = "...")`. Alternatively, compile with `-parameters`.

## Included tools

- `mcp_server_health_check`
- `add_numbers`
- `reverse_text`
- `launch_application`
- `close_application`
- `is_application_running`
- `wait_for_application`
- `capture_screen`

## Build

```bash
chmod +x build.sh run.sh test.sh
./build.sh
```

The scripts default to:

```text
/opt/advent/sdk/2.2.50.0/gw_javacots.4.0.80.c2a7e16231/lib/gson-2.8.0.jar
```

Override when necessary:

```bash
GSON_PATH=/path/to/gson.jar ./build.sh
GSON_PATH=/path/to/gson.jar ./run.sh
```
