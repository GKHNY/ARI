#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GSON_PATH="${GSON_PATH:-/opt/advent/sdk/2.2.50.0/gw_javacots.4.0.80.c2a7e16231/lib/gson-2.8.0.jar}"

if [[ ! -f "$GSON_PATH" ]]; then
  echo "Gson jar not found: $GSON_PATH" >&2
  echo "Set it explicitly: GSON_PATH=/path/to/gson.jar ./build.sh" >&2
  exit 1
fi

rm -rf "$PROJECT_DIR/out"
mkdir -p "$PROJECT_DIR/out/classes"
find "$PROJECT_DIR/src" -name '*.java' | sort > "$PROJECT_DIR/out/sources.txt"

javac \
  --release 11 \
  -encoding UTF-8 \
  -cp "$GSON_PATH" \
  -d "$PROJECT_DIR/out/classes" \
  @"$PROJECT_DIR/out/sources.txt"

jar --create \
  --file "$PROJECT_DIR/out/mcp-core.jar" \
  --main-class com.company.mcp.Main \
  -C "$PROJECT_DIR/out/classes" .

echo "Built: $PROJECT_DIR/out/mcp-core.jar"
