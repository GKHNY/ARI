package com.company.mcp;

import com.company.mcp.protocol.JsonRpcParser;
import com.company.mcp.server.JsonRpcDispatcher;
import com.company.mcp.server.McpServer;
import com.company.mcp.tool.ToolRegistry;
import com.company.mcp.tools.AddNumbersTool;
import com.company.mcp.tools.CaptureScreenTool;
import com.company.mcp.tools.CloseApplicationTool;
import com.company.mcp.tools.HealthCheckTool;
import com.company.mcp.tools.IsApplicationRunningTool;
import com.company.mcp.tools.LaunchApplicationTool;
import com.company.mcp.tools.ReverseTextTool;
import com.company.mcp.tools.WaitForApplicationTool;
import com.google.gson.Gson;

public final class Main {
    private Main() {}

    public static void main(String[] args) throws Exception {
        Gson gson = new Gson();
        ToolRegistry registry = new ToolRegistry(gson);
        registry.register(new HealthCheckTool());
        registry.register(new AddNumbersTool());
        registry.register(new ReverseTextTool());
        registry.register(new LaunchApplicationTool());
        registry.register(new CloseApplicationTool());
        registry.register(new IsApplicationRunningTool());
        registry.register(new WaitForApplicationTool());
        registry.register(new CaptureScreenTool());

        JsonRpcDispatcher dispatcher = new JsonRpcDispatcher(registry);
        new McpServer(new JsonRpcParser(), dispatcher, gson).run();
    }
}
