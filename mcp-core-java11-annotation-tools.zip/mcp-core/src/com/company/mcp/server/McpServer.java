package com.company.mcp.server;

import com.company.mcp.protocol.JsonRpcParser;
import com.company.mcp.protocol.JsonRpcRequest;
import com.company.mcp.protocol.JsonRpcResponses;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

public final class McpServer {
    private final JsonRpcParser parser;
    private final JsonRpcDispatcher dispatcher;
    private final Gson gson;

    public McpServer(JsonRpcParser parser, JsonRpcDispatcher dispatcher, Gson gson) {
        this.parser = parser;
        this.dispatcher = dispatcher;
        this.gson = gson;
    }

    public void run() throws IOException {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in, StandardCharsets.UTF_8));
        PrintWriter writer = new PrintWriter(System.out, true);

        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) {
                continue;
            }

            JsonObject response;
            try {
                JsonRpcRequest request = parser.parseRequest(line);
                response = dispatcher.dispatch(request);
            } catch (RuntimeException ex) {
                response = JsonRpcResponses.error(null, -32700, "Parse error: " + ex.getMessage());
            }

            if (response != null) {
                writer.println(gson.toJson(response));
                writer.flush();
            }
        }
    }
}
