package com.company.mcp.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.PARAMETER)
public @interface McpParam {
    String name() default "";
    String description() default "";
    boolean required() default true;
    String defaultValue() default "__MCP_NO_DEFAULT__";
}
