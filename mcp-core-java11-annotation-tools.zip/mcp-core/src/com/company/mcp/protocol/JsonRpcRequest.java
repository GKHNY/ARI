package com.company.mcp.protocol;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public final class JsonRpcRequest {
    private final JsonElement id;
    private final String method;
    private final JsonObject params;

    public JsonRpcRequest(JsonElement id, String method, JsonObject params) {
        this.id = id;
        this.method = method;
        this.params = params == null ? new JsonObject() : params;
    }

    public JsonElement getId() { return id; }
    public String getMethod() { return method; }
    public JsonObject getParams() { return params; }
    public boolean isNotification() { return id == null || id.isJsonNull(); }
}
