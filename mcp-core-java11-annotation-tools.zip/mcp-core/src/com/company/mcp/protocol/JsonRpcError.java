package com.company.mcp.protocol;

import com.google.gson.JsonElement;

public final class JsonRpcError {
    private final int code;
    private final String message;
    private final JsonElement data;

    public JsonRpcError(int code, String message, JsonElement data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public int getCode() { return code; }
    public String getMessage() { return message; }
    public JsonElement getData() { return data; }
}
