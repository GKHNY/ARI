package com.company.mcp.tools;

import com.company.mcp.annotation.McpParam;
import com.company.mcp.annotation.McpTool;
import com.company.mcp.exception.ToolException;

import javax.imageio.ImageIO;
import java.awt.AWTException;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class CaptureScreenTool {
    private static final DateTimeFormatter FILE_TIMESTAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS");

    @McpTool(name = "capture_screen", description = "Captures all desktop displays into a PNG file and returns its path.")
    public String captureScreen(
            @McpParam(name = "outputPath", description = "Absolute PNG path; empty creates a file under /tmp", required = false, defaultValue = "") String outputPath)
            throws ToolException {
        if (GraphicsEnvironment.isHeadless()) throw new ToolException("Screen capture is unavailable in a headless environment");

        Path path = resolveOutputPath(outputPath);
        Rectangle bounds = calculateAllScreenBounds();
        try {
            if (path.getParent() != null) Files.createDirectories(path.getParent());
            BufferedImage image = new Robot().createScreenCapture(bounds);
            if (!ImageIO.write(image, "png", path.toFile())) throw new ToolException("No PNG writer is available");
        } catch (AWTException | IOException | SecurityException ex) {
            throw new ToolException("Could not capture screen: " + ex.getMessage(), ex);
        }
        return path.toAbsolutePath().normalize().toString();
    }

    private static Path resolveOutputPath(String outputPath) throws ToolException {
        if (outputPath == null || outputPath.trim().isEmpty()) {
            return Paths.get("/tmp", "mcp-screen-" + FILE_TIMESTAMP.format(LocalDateTime.now()) + ".png");
        }
        String raw = outputPath.trim();
        Path path = Paths.get(raw);
        if (!path.isAbsolute()) throw new ToolException("outputPath must be absolute");
        if (!raw.toLowerCase().endsWith(".png")) throw new ToolException("outputPath must end with .png");
        return path;
    }

    private static Rectangle calculateAllScreenBounds() throws ToolException {
        GraphicsDevice[] devices = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices();
        if (devices.length == 0) throw new ToolException("No screen devices were detected");
        Rectangle combined = new Rectangle(devices[0].getDefaultConfiguration().getBounds());
        for (int i = 1; i < devices.length; i++) combined = combined.union(devices[i].getDefaultConfiguration().getBounds());
        return combined;
    }
}
