package com.company.mcp.tools;

import com.company.mcp.annotation.McpParam;
import com.company.mcp.annotation.McpTool;
import com.company.mcp.exception.ToolException;

public final class WaitForApplicationTool {
    @McpTool(name = "wait_for_application", description = "Waits until a matching application process is running.")
    public String waitForApplication(
            @McpParam(name = "applicationName", description = "Process or executable name") String applicationName,
            @McpParam(name = "timeoutSeconds", description = "Maximum wait time", required = false, defaultValue = "30") int timeoutSeconds)
            throws ToolException {
        if (applicationName == null || applicationName.trim().isEmpty()) throw new ToolException("applicationName cannot be blank");
        if (timeoutSeconds < 1) throw new ToolException("timeoutSeconds must be positive");
        applicationName = applicationName.trim();
        if (!ApplicationProcesses.waitUntilRunning(applicationName, timeoutSeconds)) {
            throw new ToolException("Timed out while waiting for application: " + applicationName);
        }
        return "Application is running: " + applicationName;
    }
}
