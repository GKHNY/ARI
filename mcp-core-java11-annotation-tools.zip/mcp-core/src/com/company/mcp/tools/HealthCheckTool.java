package com.company.mcp.tools;

import com.company.mcp.annotation.McpTool;

public final class HealthCheckTool {
    @McpTool(name = "mcp_server_health_check", description = "Checks whether this MCP server is running.")
    public String healthCheck() {
        return "pong";
    }
}
