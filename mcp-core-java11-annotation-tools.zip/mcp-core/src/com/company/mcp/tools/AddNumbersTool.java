package com.company.mcp.tools;

import com.company.mcp.annotation.McpParam;
import com.company.mcp.annotation.McpTool;

public final class AddNumbersTool {
    @McpTool(name = "add_numbers", description = "Adds two numeric values and returns their sum.")
    public double addNumbers(
            @McpParam(name = "a", description = "First number") double a,
            @McpParam(name = "b", description = "Second number") double b) {
        return a + b;
    }
}
