package com.company.mcp.tools;

import com.company.mcp.annotation.McpParam;
import com.company.mcp.annotation.McpTool;
import com.company.mcp.exception.ToolException;

public final class CloseApplicationTool {
    @McpTool(name = "close_application", description = "Stops matching application processes and waits for them to exit.")
    public String closeApplication(
            @McpParam(name = "applicationName", description = "Process or executable name") String applicationName,
            @McpParam(name = "timeoutSeconds", description = "Maximum wait time", required = false, defaultValue = "10") int timeoutSeconds,
            @McpParam(name = "force", description = "Use forcible termination", required = false, defaultValue = "false") boolean force)
            throws ToolException {
        if (applicationName == null || applicationName.trim().isEmpty()) throw new ToolException("applicationName cannot be blank");
        if (timeoutSeconds < 1) throw new ToolException("timeoutSeconds must be positive");
        applicationName = applicationName.trim();
        int count = ApplicationProcesses.stop(applicationName, force);
        if (count == 0) return "Application is not running: " + applicationName;
        if (!ApplicationProcesses.waitUntilStopped(applicationName, timeoutSeconds)) {
            throw new ToolException("Timed out while waiting for application to stop: " + applicationName);
        }
        return "Application closed: " + applicationName + "; stoppedProcesses=" + count;
    }
}
