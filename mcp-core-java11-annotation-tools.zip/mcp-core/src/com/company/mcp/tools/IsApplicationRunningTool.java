package com.company.mcp.tools;

import com.company.mcp.annotation.McpParam;
import com.company.mcp.annotation.McpTool;
import com.company.mcp.exception.ToolException;

import java.util.List;

public final class IsApplicationRunningTool {
    @McpTool(name = "is_application_running", description = "Checks whether a matching application process is running.")
    public String isApplicationRunning(
            @McpParam(name = "applicationName", description = "Process or executable name") String applicationName)
            throws ToolException {
        if (applicationName == null || applicationName.trim().isEmpty()) throw new ToolException("applicationName cannot be blank");
        applicationName = applicationName.trim();
        List<ProcessHandle> processes = ApplicationProcesses.find(applicationName);
        return "applicationName=" + applicationName
                + "; running=" + !processes.isEmpty()
                + "; processCount=" + processes.size()
                + "; pids=" + ApplicationProcesses.describe(processes);
    }
}
