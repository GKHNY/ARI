package com.company.mcp.tools;

import com.company.mcp.annotation.McpParam;
import com.company.mcp.annotation.McpTool;
import com.company.mcp.exception.ToolException;

public final class LaunchApplicationTool {
    @McpTool(name = "launch_application", description = "Launches a Linux desktop application and waits for its process.")
    public String launchApplication(
            @McpParam(name = "applicationName", description = "Process or executable name") String applicationName,
            @McpParam(name = "command", description = "Command to launch; empty means applicationName", required = false, defaultValue = "") String command,
            @McpParam(name = "timeoutSeconds", description = "Maximum wait time", required = false, defaultValue = "30") int timeoutSeconds)
            throws ToolException {
        applicationName = requireNonBlank(applicationName, "applicationName");
        if (command == null || command.trim().isEmpty()) command = applicationName;
        if (timeoutSeconds < 1) throw new ToolException("timeoutSeconds must be positive");

        if (ApplicationProcesses.isRunning(applicationName)) return "Application is already running: " + applicationName;
        Process process = ApplicationProcesses.launch(command);
        if (!ApplicationProcesses.waitUntilRunning(applicationName, timeoutSeconds)) {
            if (!process.isAlive()) throw new ToolException("Application exited before becoming ready; exitCode=" + process.exitValue());
            throw new ToolException("Timed out while waiting for application: " + applicationName);
        }
        return "Application launched: " + applicationName + "; pid=" + process.pid();
    }

    private static String requireNonBlank(String value, String name) throws ToolException {
        if (value == null || value.trim().isEmpty()) throw new ToolException(name + " cannot be blank");
        return value.trim();
    }
}
