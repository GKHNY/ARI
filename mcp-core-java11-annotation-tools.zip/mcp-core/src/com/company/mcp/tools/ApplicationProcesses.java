package com.company.mcp.tools;

import com.company.mcp.exception.ToolException;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

final class ApplicationProcesses {
    private static final long POLL_INTERVAL_MILLIS = 250L;

    private ApplicationProcesses() {}

    static Process launch(String command) throws ToolException {
        try {
            return new ProcessBuilder("/bin/sh", "-lc", "exec " + command).start();
        } catch (IOException ex) {
            throw new ToolException("Could not launch application command: " + command, ex);
        }
    }

    static boolean isRunning(String applicationName) {
        return !find(applicationName).isEmpty();
    }

    static List<ProcessHandle> find(String applicationName) {
        String needle = normalize(applicationName);
        long currentPid = ProcessHandle.current().pid();

        return ProcessHandle.allProcesses()
                .filter(ProcessHandle::isAlive)
                .filter(process -> process.pid() != currentPid)
                .filter(process -> matches(process, needle))
                .collect(Collectors.toList());
    }

    static boolean waitUntilRunning(String applicationName, int timeoutSeconds) throws ToolException {
        return waitForState(applicationName, true, timeoutSeconds);
    }

    static boolean waitUntilStopped(String applicationName, int timeoutSeconds) throws ToolException {
        return waitForState(applicationName, false, timeoutSeconds);
    }

    static int stop(String applicationName, boolean force) {
        List<ProcessHandle> processes = new ArrayList<>(find(applicationName));
        for (ProcessHandle process : processes) {
            if (force) {
                process.destroyForcibly();
            } else {
                process.destroy();
            }
        }
        return processes.size();
    }

    static String describe(List<ProcessHandle> processes) {
        return processes.stream()
                .map(process -> Long.toString(process.pid()))
                .collect(Collectors.joining(","));
    }

    private static boolean waitForState(String applicationName, boolean expectedRunning, int timeoutSeconds)
            throws ToolException {
        long timeoutNanos = Duration.ofSeconds(timeoutSeconds).toNanos();
        long deadline = System.nanoTime() + timeoutNanos;

        while (true) {
            if (isRunning(applicationName) == expectedRunning) {
                return true;
            }
            if (System.nanoTime() >= deadline) {
                return false;
            }
            try {
                TimeUnit.MILLISECONDS.sleep(POLL_INTERVAL_MILLIS);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                throw new ToolException("Interrupted while waiting for application state", ex);
            }
        }
    }

    private static boolean matches(ProcessHandle process, String needle) {
        ProcessHandle.Info info = process.info();

        Optional<String> command = info.command();
        if (command.isPresent()) {
            String fullCommand = normalize(command.get());
            String executableName = normalize(baseName(command.get()));
            if (fullCommand.equals(needle) || executableName.equals(needle)) {
                return true;
            }
        }

        Optional<String> commandLine = info.commandLine();
        return commandLine.isPresent() && normalize(commandLine.get()).contains(needle);
    }

    private static String baseName(String path) {
        int separatorIndex = path.lastIndexOf('/');
        return separatorIndex >= 0 ? path.substring(separatorIndex + 1) : path;
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }
}
