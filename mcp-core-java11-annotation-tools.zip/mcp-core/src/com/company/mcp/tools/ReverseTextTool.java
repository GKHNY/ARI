package com.company.mcp.tools;

import com.company.mcp.annotation.McpParam;
import com.company.mcp.annotation.McpTool;

public final class ReverseTextTool {
    @McpTool(name = "reverse_text", description = "Reverses the given text.")
    public String reverseText(
            @McpParam(name = "text", description = "Text to reverse") String text) {
        return new StringBuilder(text).reverse().toString();
    }
}
