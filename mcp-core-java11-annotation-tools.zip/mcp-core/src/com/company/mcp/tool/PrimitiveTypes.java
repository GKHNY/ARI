package com.company.mcp.tool;

final class PrimitiveTypes {
    private PrimitiveTypes() {}

    static boolean isSupported(Class<?> type) {
        return type == String.class
                || type == boolean.class || type == Boolean.class
                || type == byte.class || type == Byte.class
                || type == short.class || type == Short.class
                || type == int.class || type == Integer.class
                || type == long.class || type == Long.class
                || type == float.class || type == Float.class
                || type == double.class || type == Double.class
                || type == char.class || type == Character.class
                || type == void.class || type == Void.class;
    }

    static String schemaType(Class<?> type) {
        if (type == String.class || type == char.class || type == Character.class) return "string";
        if (type == boolean.class || type == Boolean.class) return "boolean";
        if (type == float.class || type == Float.class || type == double.class || type == Double.class) return "number";
        return "integer";
    }
}
