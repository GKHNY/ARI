package com.company.mcp.tool;

import com.company.mcp.annotation.McpTool;
import com.google.gson.Gson;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ToolRegistry {
    private final Map<String, Tool> tools = new LinkedHashMap<>();
    private final Gson gson;

    public ToolRegistry(Gson gson) {
        this.gson = gson;
    }

    public void register(Object toolObject) {
        if (toolObject == null) throw new IllegalArgumentException("Tool object cannot be null");
        int registered = 0;
        for (Method method : toolObject.getClass().getDeclaredMethods()) {
            if (!method.isAnnotationPresent(McpTool.class)) continue;
            registerTool(new MethodTool(toolObject, method, gson));
            registered++;
        }
        if (registered == 0) {
            throw new IllegalArgumentException("No @McpTool methods found in " + toolObject.getClass().getName());
        }
    }

    private void registerTool(Tool tool) {
        if (tools.containsKey(tool.getName())) throw new IllegalArgumentException("Tool already registered: " + tool.getName());
        tools.put(tool.getName(), tool);
    }

    public Tool get(String name) { return tools.get(name); }
    public Collection<Tool> getAll() { return Collections.unmodifiableCollection(tools.values()); }
}
