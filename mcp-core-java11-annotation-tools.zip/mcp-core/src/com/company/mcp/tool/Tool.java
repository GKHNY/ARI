package com.company.mcp.tool;

import com.company.mcp.exception.ToolException;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public interface Tool {
    String getName();
    String getDescription();
    JsonObject getInputSchema();
    JsonElement execute(JsonObject arguments) throws ToolException;
}
