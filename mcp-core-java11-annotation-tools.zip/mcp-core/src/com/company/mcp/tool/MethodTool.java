package com.company.mcp.tool;

import com.company.mcp.annotation.McpParam;
import com.company.mcp.annotation.McpTool;
import com.company.mcp.exception.ToolException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

final class MethodTool implements Tool {
    private static final String NO_DEFAULT = "__MCP_NO_DEFAULT__";

    private final Object target;
    private final Method method;
    private final Gson gson;
    private final String name;
    private final String description;
    private final JsonObject inputSchema;

    MethodTool(Object target, Method method, Gson gson) {
        this.target = target;
        this.method = method;
        this.gson = gson;

        McpTool annotation = method.getAnnotation(McpTool.class);
        this.name = resolveToolName(annotation, method);
        this.description = annotation.description();
        validateSignature(method);
        this.inputSchema = createInputSchema(method);
        method.setAccessible(true);
    }

    @Override public String getName() { return name; }
    @Override public String getDescription() { return description; }
    @Override public JsonObject getInputSchema() { return inputSchema; }

    @Override
    public JsonElement execute(JsonObject arguments) throws ToolException {
        Object[] values = new Object[method.getParameterCount()];
        Parameter[] parameters = method.getParameters();

        for (int i = 0; i < parameters.length; i++) {
            Parameter parameter = parameters[i];
            McpParam annotation = parameter.getAnnotation(McpParam.class);
            String parameterName = resolveParameterName(parameter, annotation);
            JsonElement value = arguments.get(parameterName);

            if (value == null || value.isJsonNull()) {
                String defaultValue = annotation == null ? NO_DEFAULT : annotation.defaultValue();
                if (!NO_DEFAULT.equals(defaultValue)) {
                    values[i] = parseDefault(defaultValue, parameter.getType(), parameterName);
                } else if (annotation != null && !annotation.required()) {
                    values[i] = defaultJavaValue(parameter.getType());
                } else {
                    throw new ToolException("Missing required argument: " + parameterName);
                }
            } else {
                values[i] = parseJson(value, parameter.getType(), parameterName);
            }
        }

        try {
            Object result = method.invoke(target, values);
            return method.getReturnType() == void.class ? JsonNull.INSTANCE : gson.toJsonTree(result);
        } catch (IllegalAccessException ex) {
            throw new ToolException("Cannot access tool method: " + name, ex);
        } catch (InvocationTargetException ex) {
            Throwable cause = ex.getCause();
            if (cause instanceof ToolException) throw (ToolException) cause;
            String message = cause == null ? "Unknown tool error" : cause.getMessage();
            throw new ToolException(message == null ? cause.getClass().getSimpleName() : message, cause);
        }
    }

    private Object parseJson(JsonElement value, Class<?> type, String name) throws ToolException {
        try {
            if (type == String.class) {
                if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) throw new IllegalArgumentException();
                return value.getAsString();
            }
            if (type == char.class || type == Character.class) {
                String text = value.getAsString();
                if (text.length() != 1) throw new IllegalArgumentException();
                return text.charAt(0);
            }
            return gson.fromJson(value, type);
        } catch (RuntimeException ex) {
            throw new ToolException("Argument '" + name + "' must be a valid " + PrimitiveTypes.schemaType(type), ex);
        }
    }

    private Object parseDefault(String value, Class<?> type, String name) throws ToolException {
        try {
            if (type == String.class) return value;
            if (type == char.class || type == Character.class) {
                if (value.length() != 1) throw new IllegalArgumentException();
                return value.charAt(0);
            }
            if (type == boolean.class || type == Boolean.class) return Boolean.parseBoolean(value);
            if (type == byte.class || type == Byte.class) return Byte.parseByte(value);
            if (type == short.class || type == Short.class) return Short.parseShort(value);
            if (type == int.class || type == Integer.class) return Integer.parseInt(value);
            if (type == long.class || type == Long.class) return Long.parseLong(value);
            if (type == float.class || type == Float.class) return Float.parseFloat(value);
            if (type == double.class || type == Double.class) return Double.parseDouble(value);
            throw new IllegalArgumentException();
        } catch (RuntimeException ex) {
            throw new ToolException("Invalid default value for parameter '" + name + "'", ex);
        }
    }

    private static Object defaultJavaValue(Class<?> type) {
        if (!type.isPrimitive()) return null;
        if (type == boolean.class) return false;
        if (type == char.class) return '\0';
        if (type == byte.class) return (byte) 0;
        if (type == short.class) return (short) 0;
        if (type == int.class) return 0;
        if (type == long.class) return 0L;
        if (type == float.class) return 0F;
        if (type == double.class) return 0D;
        return null;
    }

    private static JsonObject createInputSchema(Method method) {
        JsonObject properties = new JsonObject();
        JsonArray required = new JsonArray();

        for (Parameter parameter : method.getParameters()) {
            McpParam annotation = parameter.getAnnotation(McpParam.class);
            String parameterName = resolveParameterName(parameter, annotation);
            JsonObject property = new JsonObject();
            property.addProperty("type", PrimitiveTypes.schemaType(parameter.getType()));

            if (annotation != null && !annotation.description().isEmpty()) {
                property.addProperty("description", annotation.description());
            }
            if (annotation != null && !NO_DEFAULT.equals(annotation.defaultValue())) {
                addDefault(property, annotation.defaultValue(), parameter.getType());
            }
            properties.add(parameterName, property);

            boolean isRequired = annotation == null || annotation.required();
            boolean hasDefault = annotation != null && !NO_DEFAULT.equals(annotation.defaultValue());
            if (isRequired && !hasDefault) required.add(parameterName);
        }

        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        schema.add("properties", properties);
        schema.add("required", required);
        schema.addProperty("additionalProperties", false);
        return schema;
    }

    private static void addDefault(JsonObject property, String value, Class<?> type) {
        if (type == boolean.class || type == Boolean.class) property.addProperty("default", Boolean.parseBoolean(value));
        else if (type == byte.class || type == Byte.class || type == short.class || type == Short.class
                || type == int.class || type == Integer.class || type == long.class || type == Long.class) {
            property.addProperty("default", Long.parseLong(value));
        } else if (type == float.class || type == Float.class || type == double.class || type == Double.class) {
            property.addProperty("default", Double.parseDouble(value));
        } else property.addProperty("default", value);
    }

    private static void validateSignature(Method method) {
        for (Parameter parameter : method.getParameters()) {
            if (!PrimitiveTypes.isSupported(parameter.getType()) || parameter.getType() == void.class) {
                throw new IllegalArgumentException("Unsupported parameter type in " + method + ": " + parameter.getType().getName());
            }
            resolveParameterName(parameter, parameter.getAnnotation(McpParam.class));
        }
        if (!PrimitiveTypes.isSupported(method.getReturnType())) {
            throw new IllegalArgumentException("Unsupported return type in " + method + ": " + method.getReturnType().getName());
        }
    }

    private static String resolveToolName(McpTool annotation, Method method) {
        if (!annotation.name().trim().isEmpty()) return annotation.name().trim();
        if (!annotation.value().trim().isEmpty()) return annotation.value().trim();
        return method.getName();
    }

    private static String resolveParameterName(Parameter parameter, McpParam annotation) {
        if (annotation != null && !annotation.name().trim().isEmpty()) return annotation.name().trim();
        if (parameter.isNamePresent()) return parameter.getName();
        throw new IllegalArgumentException("Parameter name is unavailable for " + parameter
                + ". Add @McpParam(name=\"...\") or compile with -parameters.");
    }
}
