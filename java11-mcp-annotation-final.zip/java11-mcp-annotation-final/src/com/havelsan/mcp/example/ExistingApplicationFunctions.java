package com.havelsan.mcp.example;

import com.havelsan.mcp.annotation.McpParam;
import com.havelsan.mcp.annotation.McpTool;

/**
 * Example only.
 * Replace the method bodies with calls to your already-existing application services/functions.
 */
public final class ExistingApplicationFunctions {

    @McpTool(
            name = "mcp_server_health_check",
            description = "Returns MCP server health information"
    )
    public String healthCheck() {
        return "OK";
    }

    @McpTool(
            name = "add_numbers",
            description = "Adds two integer numbers"
    )
    public int addNumbers(
            @McpParam(name = "a", description = "First integer") int a,
            @McpParam(name = "b", description = "Second integer") int b) {
        return a + b;
    }

    @McpTool(
            name = "open_application",
            description = "Example wrapper around an existing application function"
    )
    public String openApplication(
            @McpParam(name = "applicationName", description = "Application name") String applicationName) {
        // Replace with your real function, e.g. applicationService.open(applicationName);
        return "Requested application: " + applicationName;
    }
}
