package com.havelsan.mcp.server;

import com.havelsan.mcp.rpc.JsonRpcDispatcher;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

public final class McpServer {
    private final JsonRpcDispatcher dispatcher;

    public McpServer(JsonRpcDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    public void runStdio() throws IOException {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in, StandardCharsets.UTF_8));
        BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(System.out, StandardCharsets.UTF_8));

        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) {
                continue;
            }

            String response = dispatcher.dispatch(line);
            if (response != null) {
                writer.write(response);
                writer.newLine();
                writer.flush();
            }
        }
    }
}
