package com.havelsan.mcp.core;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.havelsan.mcp.annotation.McpTool;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ToolRegistry {
    private final Map<String, MethodTool> tools = new LinkedHashMap<String, MethodTool>();
    private final Gson gson;

    public ToolRegistry(Gson gson) {
        this.gson = gson;
    }

    public ToolRegistry register(Object service) {
        if (service == null) {
            throw new IllegalArgumentException("service cannot be null");
        }

        for (Method method : service.getClass().getDeclaredMethods()) {
            if (!method.isAnnotationPresent(McpTool.class)) {
                continue;
            }

            MethodTool tool = new MethodTool(service, method, gson);
            MethodTool previous = tools.put(tool.getName(), tool);
            if (previous != null) {
                throw new IllegalStateException("Duplicate MCP tool name: " + tool.getName());
            }
        }
        return this;
    }

    public JsonArray listDefinitions() {
        JsonArray array = new JsonArray();
        for (MethodTool tool : tools.values()) {
            array.add(tool.toMcpDefinition());
        }
        return array;
    }

    public MethodTool get(String name) {
        return tools.get(name);
    }
}
