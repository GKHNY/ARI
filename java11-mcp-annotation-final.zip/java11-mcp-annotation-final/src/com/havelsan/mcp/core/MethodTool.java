package com.havelsan.mcp.core;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.havelsan.mcp.annotation.McpParam;
import com.havelsan.mcp.annotation.McpTool;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.List;

public final class MethodTool {
    private final Object target;
    private final Method method;
    private final McpTool toolAnnotation;
    private final Gson gson;

    public MethodTool(Object target, Method method, Gson gson) {
        this.target = target;
        this.method = method;
        this.toolAnnotation = method.getAnnotation(McpTool.class);
        this.gson = gson;
        this.method.setAccessible(true);
    }

    public String getName() {
        return toolAnnotation.name();
    }

    public JsonObject toMcpDefinition() {
        JsonObject definition = new JsonObject();
        definition.addProperty("name", toolAnnotation.name());
        definition.addProperty("description", toolAnnotation.description());
        definition.add("inputSchema", buildInputSchema());
        return definition;
    }

    private JsonObject buildInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");

        JsonObject properties = new JsonObject();
        JsonArray required = new JsonArray();

        Parameter[] parameters = method.getParameters();
        for (int i = 0; i < parameters.length; i++) {
            Parameter parameter = parameters[i];
            McpParam annotation = parameter.getAnnotation(McpParam.class);

            String name = annotation != null ? annotation.name() : parameter.getName();
            JsonObject property = schemaForType(parameter.getType());

            if (annotation != null && !annotation.description().isEmpty()) {
                property.addProperty("description", annotation.description());
            }

            properties.add(name, property);
            if (annotation == null || annotation.required()) {
                required.add(name);
            }
        }

        schema.add("properties", properties);
        if (required.size() > 0) {
            schema.add("required", required);
        }
        schema.addProperty("additionalProperties", false);
        return schema;
    }

    private JsonObject schemaForType(Class<?> type) {
        JsonObject schema = new JsonObject();

        if (type == String.class || type == Character.class || type == char.class || type.isEnum()) {
            schema.addProperty("type", "string");
            if (type.isEnum()) {
                JsonArray values = new JsonArray();
                Object[] constants = type.getEnumConstants();
                for (Object constant : constants) {
                    values.add(String.valueOf(constant));
                }
                schema.add("enum", values);
            }
        } else if (type == boolean.class || type == Boolean.class) {
            schema.addProperty("type", "boolean");
        } else if (type == byte.class || type == Byte.class ||
                   type == short.class || type == Short.class ||
                   type == int.class || type == Integer.class ||
                   type == long.class || type == Long.class) {
            schema.addProperty("type", "integer");
        } else if (type == float.class || type == Float.class ||
                   type == double.class || type == Double.class) {
            schema.addProperty("type", "number");
        } else if (type.isArray() || Iterable.class.isAssignableFrom(type)) {
            schema.addProperty("type", "array");
        } else {
            schema.addProperty("type", "object");
        }

        return schema;
    }

    public JsonElement invoke(JsonObject arguments) throws Exception {
        Parameter[] parameters = method.getParameters();
        Object[] values = new Object[parameters.length];
        List<String> missing = new ArrayList<String>();

        for (int i = 0; i < parameters.length; i++) {
            Parameter parameter = parameters[i];
            McpParam annotation = parameter.getAnnotation(McpParam.class);
            String name = annotation != null ? annotation.name() : parameter.getName();
            boolean required = annotation == null || annotation.required();

            JsonElement value = arguments == null ? null : arguments.get(name);
            if ((value == null || value.isJsonNull()) && required) {
                missing.add(name);
                continue;
            }

            if (value == null || value.isJsonNull()) {
                values[i] = defaultValue(parameter.getType());
            } else {
                values[i] = gson.fromJson(value, parameter.getType());
            }
        }

        if (!missing.isEmpty()) {
            throw new IllegalArgumentException("Missing required parameter(s): " + String.join(", ", missing));
        }

        try {
            Object result = method.invoke(target, values);
            if (method.getReturnType() == void.class) {
                return JsonNull.INSTANCE;
            }
            return gson.toJsonTree(result);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            if (cause instanceof Exception) {
                throw (Exception) cause;
            }
            throw new RuntimeException(cause);
        }
    }

    private Object defaultValue(Class<?> type) {
        if (!type.isPrimitive()) {
            return null;
        }
        if (type == boolean.class) return false;
        if (type == byte.class) return (byte) 0;
        if (type == short.class) return (short) 0;
        if (type == int.class) return 0;
        if (type == long.class) return 0L;
        if (type == float.class) return 0F;
        if (type == double.class) return 0D;
        if (type == char.class) return '\0';
        return null;
    }
}
