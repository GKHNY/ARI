package com.havelsan.mcp.rpc;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.havelsan.mcp.core.MethodTool;
import com.havelsan.mcp.core.ToolRegistry;

public final class JsonRpcDispatcher {
    private final Gson gson;
    private final ToolRegistry registry;

    public JsonRpcDispatcher(Gson gson, ToolRegistry registry) {
        this.gson = gson;
        this.registry = registry;
    }

    public String dispatch(String jsonLine) {
        JsonObject request;
        try {
            request = new JsonParser().parse(jsonLine).getAsJsonObject();
        } catch (Exception e) {
            return gson.toJson(error(JsonNull.INSTANCE, -32700, "Parse error", e.getMessage()));
        }

        JsonElement id = request.has("id") ? request.get("id") : JsonNull.INSTANCE;
        String method = request.has("method") ? request.get("method").getAsString() : null;
        JsonObject params = request.has("params") && request.get("params").isJsonObject()
                ? request.getAsJsonObject("params")
                : new JsonObject();

        // Notifications do not get a response.
        boolean notification = !request.has("id");

        try {
            JsonElement result;

            if ("initialize".equals(method)) {
                result = initializeResult();
            } else if ("notifications/initialized".equals(method)) {
                return null;
            } else if ("ping".equals(method)) {
                result = new JsonObject();
            } else if ("tools/list".equals(method)) {
                JsonObject obj = new JsonObject();
                obj.add("tools", registry.listDefinitions());
                result = obj;
            } else if ("tools/call".equals(method)) {
                result = callTool(params);
            } else {
                if (notification) return null;
                return gson.toJson(error(id, -32601, "Method not found", method));
            }

            if (notification) return null;
            return gson.toJson(success(id, result));
        } catch (IllegalArgumentException e) {
            if (notification) return null;
            return gson.toJson(error(id, -32602, "Invalid params", e.getMessage()));
        } catch (Exception e) {
            if (notification) return null;
            return gson.toJson(error(id, -32603, "Internal error", e.toString()));
        }
    }

    private JsonObject initializeResult() {
        JsonObject result = new JsonObject();
        result.addProperty("protocolVersion", "2024-11-05");

        JsonObject capabilities = new JsonObject();
        JsonObject tools = new JsonObject();
        tools.addProperty("listChanged", false);
        capabilities.add("tools", tools);
        result.add("capabilities", capabilities);

        JsonObject serverInfo = new JsonObject();
        serverInfo.addProperty("name", "java11-annotation-mcp");
        serverInfo.addProperty("version", "1.0.0");
        result.add("serverInfo", serverInfo);
        return result;
    }

    private JsonObject callTool(JsonObject params) throws Exception {
        if (!params.has("name")) {
            throw new IllegalArgumentException("tools/call requires params.name");
        }

        String name = params.get("name").getAsString();
        MethodTool tool = registry.get(name);
        if (tool == null) {
            throw new IllegalArgumentException("Unknown tool: " + name);
        }

        JsonObject arguments = params.has("arguments") && params.get("arguments").isJsonObject()
                ? params.getAsJsonObject("arguments")
                : new JsonObject();

        JsonElement value = tool.invoke(arguments);

        JsonObject result = new JsonObject();
        JsonArray content = new JsonArray();
        JsonObject text = new JsonObject();
        text.addProperty("type", "text");
        text.addProperty("text", renderToolResult(value));
        content.add(text);
        result.add("content", content);
        result.addProperty("isError", false);
        return result;
    }

    private String renderToolResult(JsonElement value) {
        if (value == null || value.isJsonNull()) {
            return "OK";
        }
        if (value.isJsonPrimitive()) {
            JsonPrimitive p = value.getAsJsonPrimitive();
            if (p.isString()) return p.getAsString();
            return p.toString();
        }
        return gson.toJson(value);
    }

    private JsonObject success(JsonElement id, JsonElement result) {
        JsonObject response = new JsonObject();
        response.addProperty("jsonrpc", "2.0");
        response.add("id", id == null ? JsonNull.INSTANCE : id);
        response.add("result", result == null ? JsonNull.INSTANCE : result);
        return response;
    }

    private JsonObject error(JsonElement id, int code, String message, String data) {
        JsonObject response = new JsonObject();
        response.addProperty("jsonrpc", "2.0");
        response.add("id", id == null ? JsonNull.INSTANCE : id);

        JsonObject error = new JsonObject();
        error.addProperty("code", code);
        error.addProperty("message", message);
        if (data != null) error.addProperty("data", data);
        response.add("error", error);
        return response;
    }
}
