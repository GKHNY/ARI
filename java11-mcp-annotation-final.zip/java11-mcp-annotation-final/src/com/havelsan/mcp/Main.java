package com.havelsan.mcp;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.havelsan.mcp.core.ToolRegistry;
import com.havelsan.mcp.example.ExistingApplicationFunctions;
import com.havelsan.mcp.rpc.JsonRpcDispatcher;
import com.havelsan.mcp.server.McpServer;

public final class Main {
    private Main() {
    }

    public static void main(String[] args) throws Exception {
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();

        ToolRegistry registry = new ToolRegistry(gson)
                .register(new ExistingApplicationFunctions());

        JsonRpcDispatcher dispatcher = new JsonRpcDispatcher(gson, registry);
        McpServer server = new McpServer(dispatcher);
        server.runStdio();
    }
}
