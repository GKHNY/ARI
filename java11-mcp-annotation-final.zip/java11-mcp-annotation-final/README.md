# Java 11 Annotation-Based MCP Server

Bu paket, daha önce konuştuğumuz **son sade yapının yeniden oluşturulmuş hali**dir:

- Java 11
- Gson 2.8.x
- `@McpTool` ile mevcut Java metodunu tool'a çevirme
- `@McpParam` ile parametre adı/açıklaması
- Reflection ile otomatik `tools/list` şeması üretme
- Reflection ile `tools/call` -> Java method invocation
- JSON-RPC `initialize`, `ping`, `tools/list`, `tools/call`
- STDIO transport
- Maven/Gradle zorunlu değil

## Yapı

```text
src/com/havelsan/mcp/
├── Main.java
├── annotation/
│   ├── McpTool.java
│   └── McpParam.java
├── core/
│   ├── MethodTool.java
│   └── ToolRegistry.java
├── rpc/
│   └── JsonRpcDispatcher.java
├── server/
│   └── McpServer.java
└── example/
    └── ExistingApplicationFunctions.java
```

## Mevcut fonksiyonu tool yapmak

```java
@McpTool(name = "add_numbers", description = "Adds two integers")
public int addNumbers(
    @McpParam(name = "a") int a,
    @McpParam(name = "b") int b
) {
    return a + b;
}
```

Sonra bu metodun bulunduğu instance'ı registry'ye ekle:

```java
ToolRegistry registry = new ToolRegistry(gson)
    .register(existingApplicationService);
```

## Derleme

`lib/gson-2.8.0.jar` dosyasını bu klasöre koyduğunu varsayarak:

Linux/macOS:

```bash
mkdir -p out
javac -encoding UTF-8 -parameters \
  -cp lib/gson-2.8.0.jar \
  -d out \
  $(find src -name '*.java')
```

Çalıştırma:

```bash
java -cp out:lib/gson-2.8.0.jar com.havelsan.mcp.Main
```

Windows classpath separator `;` olur:

```bat
java -cp out;lib\gson-2.8.0.jar com.havelsan.mcp.Main
```

## Elle tools/list testi

```json
{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}
```

## Elle tools/call testi

```json
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"add_numbers","arguments":{"a":3,"b":4}}}
```

## Çalışan uygulamadaki fonksiyonları kullanma

### 1. MCP server aynı JVM içine gömülürse
En temiz yol budur. Mevcut service/object instance'larını doğrudan `ToolRegistry.register(instance)` ile kaydedebilirsin.

```text
MCP Client
   ↓
Embedded MCP Server
   ↓
ToolRegistry / reflection
   ↓
Existing Java Service Method
```

### 2. MCP server ayrı process ise
Başka JVM'deki metodu reflection ile doğrudan çağıramaz. Mevcut uygulamada küçük bir internal API/command layer gerekir.

```text
MCP Client
   ↓
MCP Server
   ↓
Tool method
   ↓
localhost/internal API
   ↓
Running ADVENT/OI application
```

Swing/OI fonksiyonları UI state değiştiriyorsa, mevcut uygulama içinde çağrıların EDT kurallarına (`SwingUtilities.invokeLater/invokeAndWait`) uygun yapılması gerekir.

## Not

Bu ZIP, eski konuşmadaki kaynak dosyanın byte-for-byte kopyası değildir; geçmiş konuşmadaki son mimari ve sınıf isimleri temel alınarak yeniden oluşturulmuştur.
