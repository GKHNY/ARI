SIMPLE JAVA MCP SERVER
======================

Gereksinimler:
- Java 11 + javac
- /opt/advent/sdk altında bir gson-*.jar
- Root veya internet gerekmez

Kurulum:
  unzip simple-java-mcp.zip
  cd simple-java-mcp
  chmod +x install.sh
  ./install.sh

Test:
  ./test.sh

Beklenen son cevaplardan biri:
  ..."text":"pong"...

VS Code'a ekleme:
1. Ctrl+Shift+P
2. MCP: Add Server
3. Command seç
4. Bu klasördeki run.sh dosyasının TAM yolunu gir
   Örnek: /home/kullanici/simple-java-mcp/run.sh
5. İsim: simple-java-mcp
6. MCP sunucusunu başlat/yenile

Notlar:
- stdout yalnızca MCP JSON mesajları içindir.
- Loglar stderr'e yazılmalıdır.
- find-gson.sh en yüksek sürümlü gson jar'ını otomatik seçer.
- Gerekirse jar yolunu elle zorlayabilirsin:
    export GSON=/tam/yol/gson-2.8.0.jar
    ./build.sh
