import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

/** Minimal Java 11 MCP server over stdio. Compatible with older Gson versions. */
public final class SimpleMcpServer {
    private static final PrintWriter OUT = new PrintWriter(System.out, true);
    private static String negotiatedProtocolVersion = "2024-11-05";

    private SimpleMcpServer() {}

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in, StandardCharsets.UTF_8));

        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) {
                continue;
            }

            try {
                JsonObject request = new JsonParser().parse(line).getAsJsonObject();
                handleMessage(request);
            } catch (Exception e) {
                // stdout is reserved for MCP messages.
                System.err.println("MCP request error: " + e.getMessage());
            }
        }
    }

    private static void handleMessage(JsonObject request) {
        String method = request.has("method")
                ? request.get("method").getAsString()
                : null;
        JsonElement id = request.get("id");

        if ("initialize".equals(method)) {
            JsonObject params = getObject(request, "params");
            if (params != null && params.has("protocolVersion")) {
                negotiatedProtocolVersion = params.get("protocolVersion").getAsString();
            }
            sendInitializeResponse(id);
            return;
        }

        if ("notifications/initialized".equals(method)
                || "notifications/cancelled".equals(method)) {
            return; // Notifications do not receive responses.
        }

        if ("ping".equals(method)) {
            sendResult(id, new JsonObject());
            return;
        }

        if ("tools/list".equals(method)) {
            sendToolsList(id);
            return;
        }

        if ("tools/call".equals(method)) {
            callTool(id, getObject(request, "params"));
            return;
        }

        if (id != null && !id.isJsonNull()) {
            sendError(id, -32601, "Method not found: " + method);
        }
    }

    private static JsonObject getObject(JsonObject parent, String name) {
        if (parent == null || !parent.has(name) || !parent.get(name).isJsonObject()) {
            return null;
        }
        return parent.getAsJsonObject(name);
    }

    private static void sendInitializeResponse(JsonElement id) {
        JsonObject toolsCapability = new JsonObject();
        toolsCapability.addProperty("listChanged", false);

        JsonObject capabilities = new JsonObject();
        capabilities.add("tools", toolsCapability);

        JsonObject serverInfo = new JsonObject();
        serverInfo.addProperty("name", "simple-java-mcp");
        serverInfo.addProperty("version", "1.0.0");

        JsonObject result = new JsonObject();
        result.addProperty("protocolVersion", negotiatedProtocolVersion);
        result.add("capabilities", capabilities);
        result.add("serverInfo", serverInfo);

        sendResult(id, result);
    }

    private static void sendToolsList(JsonElement id) {
        JsonObject properties = new JsonObject();

        JsonObject inputSchema = new JsonObject();
        inputSchema.addProperty("type", "object");
        inputSchema.add("properties", properties);
        inputSchema.addProperty("additionalProperties", false);

        JsonObject pingTool = new JsonObject();
        pingTool.addProperty("name", "ping");
        pingTool.addProperty("description", "MCP sunucusunun çalıştığını kontrol eder ve pong döndürür.");
        pingTool.add("inputSchema", inputSchema);

        JsonArray tools = new JsonArray();
        tools.add(pingTool);

        JsonObject result = new JsonObject();
        result.add("tools", tools);
        sendResult(id, result);
    }

    private static void callTool(JsonElement id, JsonObject params) {
        if (params == null || !params.has("name")) {
            sendToolText(id, "Tool adı gönderilmedi.", true);
            return;
        }

        String toolName = params.get("name").getAsString();
        if ("ping".equals(toolName)) {
            sendToolText(id, "pong", false);
        } else {
            sendToolText(id, "Tool bulunamadı: " + toolName, true);
        }
    }

    private static void sendToolText(JsonElement id, String text, boolean isError) {
        JsonObject textContent = new JsonObject();
        textContent.addProperty("type", "text");
        textContent.addProperty("text", text);

        JsonArray content = new JsonArray();
        content.add(textContent);

        JsonObject result = new JsonObject();
        result.add("content", content);
        result.addProperty("isError", isError);
        sendResult(id, result);
    }

    private static void sendResult(JsonElement id, JsonObject result) {
        JsonObject response = new JsonObject();
        response.addProperty("jsonrpc", "2.0");
        response.add("id", id);
        response.add("result", result);
        OUT.println(response.toString());
    }

    private static void sendError(JsonElement id, int code, String message) {
        JsonObject error = new JsonObject();
        error.addProperty("code", code);
        error.addProperty("message", message);

        JsonObject response = new JsonObject();
        response.addProperty("jsonrpc", "2.0");
        response.add("id", id);
        response.add("error", error);
        OUT.println(response.toString());
    }
}
