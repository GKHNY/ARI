#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
GSON_PATH="$(./find-gson.sh)"
echo "Gson: $GSON_PATH"
echo "Java: $(java -version 2>&1 | head -n 1)"
echo "Javac: $(javac -version 2>&1)"
rm -rf build
mkdir -p build
javac -encoding UTF-8 -cp "$GSON_PATH" -d build SimpleMcpServer.java
printf '%s\n' "$GSON_PATH" > build/gson.path
echo "Derleme tamamlandı."
