#!/usr/bin/env bash
set -euo pipefail

if [[ -n "${GSON:-}" && -f "$GSON" ]]; then
  printf '%s\n' "$GSON"
  exit 0
fi

SEARCH_ROOT="${1:-/opt/advent/sdk}"
GSON_PATH=$(find "$SEARCH_ROOT" -type f -iname 'gson-*.jar' 2>/dev/null \
  | sort -V \
  | tail -n 1 || true)

if [[ -z "$GSON_PATH" ]]; then
  echo "Gson jar bulunamadı. GSON değişkenini elle ver:" >&2
  echo "  export GSON=/tam/yol/gson-x.y.z.jar" >&2
  exit 1
fi

printf '%s\n' "$GSON_PATH"
