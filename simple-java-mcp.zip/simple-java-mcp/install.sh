#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
chmod +x find-gson.sh build.sh run.sh test.sh install.sh
./build.sh
cat <<MSG

Hazır.

Elle test:
  ./test.sh

VS Code > MCP: Add Server > Command alanına şu tam yolu gir:
  $(pwd)/run.sh

Sunucu adı sorulursa:
  simple-java-mcp
MSG
