#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -f build/SimpleMcpServer.class ]]; then
  ./build.sh >&2
fi
GSON_PATH="$(cat build/gson.path)"
exec java -cp "build:$GSON_PATH" SimpleMcpServer
