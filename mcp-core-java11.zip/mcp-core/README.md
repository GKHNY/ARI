# mcp-core

Small Java 11-compatible MCP server foundation using stdio and Gson.

## Included tools

- `mcp_server_health_check`
- `add_numbers`

## Build

```bash
chmod +x build.sh run.sh test.sh
./build.sh
```

The scripts default to:

```text
/opt/advent/sdk/2.2.50.0/gw_javacots.4.0.80.c2a7e16231/lib/gson-2.8.0.jar
```

Override it when necessary:

```bash
GSON_PATH=/path/to/gson.jar ./build.sh
GSON_PATH=/path/to/gson.jar ./run.sh
```

## Test

```bash
./test.sh
```

## Kilo / VS Code MCP configuration

```json
{
  "servers": {
    "mcp-core": {
      "type": "stdio",
      "command": "/absolute/path/to/mcp-core/run.sh"
    }
  }
}
```

Run `./build.sh` and restart the MCP server after source changes.

## Add a tool

1. Implement `Tool` or extend `BaseTool`.
2. Register it in `Main`.
3. Rebuild and restart the MCP server.

Automatic discovery, dependency injection, retries and permissions are intentionally not included yet.
