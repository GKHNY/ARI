package com.company.mcp.tool;

import com.company.mcp.exception.ToolException;

public abstract class BaseTool implements Tool {
    @Override
    public final ToolResponse execute(ToolRequest request, ToolContext context) throws ToolException {
        if (request == null) {
            throw new ToolException("Tool request cannot be null");
        }
        if (context == null) {
            throw new ToolException("Tool context cannot be null");
        }
        return executeInternal(request, context);
    }

    protected abstract ToolResponse executeInternal(ToolRequest request, ToolContext context)
            throws ToolException;
}
