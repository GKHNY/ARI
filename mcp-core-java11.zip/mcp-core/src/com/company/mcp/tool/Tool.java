package com.company.mcp.tool;

import com.google.gson.JsonObject;
import com.company.mcp.exception.ToolException;

public interface Tool {
    String getName();
    String getDescription();
    JsonObject getInputSchema();
    ToolResponse execute(ToolRequest request, ToolContext context) throws ToolException;
}
