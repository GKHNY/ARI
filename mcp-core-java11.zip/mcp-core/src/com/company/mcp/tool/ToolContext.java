package com.company.mcp.tool;

/**
 * Shared execution context for tools.
 * Intentionally empty in the first version. Services/configuration can be added later.
 */
public final class ToolContext {
}
