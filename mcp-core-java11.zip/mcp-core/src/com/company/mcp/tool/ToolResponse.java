package com.company.mcp.tool;

public final class ToolResponse {
    private final boolean success;
    private final String message;

    private ToolResponse(boolean success, String message) {
        this.success = success;
        this.message = message == null ? "" : message;
    }

    public static ToolResponse ok(String message) {
        return new ToolResponse(true, message);
    }

    public static ToolResponse error(String message) {
        return new ToolResponse(false, message);
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}
