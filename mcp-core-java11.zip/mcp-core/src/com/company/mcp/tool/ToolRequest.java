package com.company.mcp.tool;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.company.mcp.exception.ToolException;

public final class ToolRequest {
    private final JsonObject arguments;

    public ToolRequest(JsonObject arguments) {
        this.arguments = arguments == null ? new JsonObject() : arguments;
    }

    public JsonObject getArguments() {
        return arguments;
    }

    public boolean has(String key) {
        return arguments.has(key) && !arguments.get(key).isJsonNull();
    }

    public String getRequiredString(String key) throws ToolException {
        JsonElement value = getRequired(key);
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) {
            throw new ToolException("Argument '" + key + "' must be a string");
        }
        return value.getAsString();
    }

    public double getRequiredDouble(String key) throws ToolException {
        JsonElement value = getRequired(key);
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) {
            throw new ToolException("Argument '" + key + "' must be a number");
        }
        try {
            return value.getAsDouble();
        } catch (NumberFormatException ex) {
            throw new ToolException("Argument '" + key + "' must be a valid number", ex);
        }
    }

    private JsonElement getRequired(String key) throws ToolException {
        if (!has(key)) {
            throw new ToolException("Missing required argument: " + key);
        }
        return arguments.get(key);
    }
}
