package com.company.mcp.protocol;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public final class JsonRpcParser {
    public JsonRpcRequest parseRequest(String line) {
        JsonElement parsed = JsonParser.parseString(line);
        if (!parsed.isJsonObject()) {
            throw new IllegalArgumentException("JSON-RPC message must be an object");
        }

        JsonObject object = parsed.getAsJsonObject();
        String jsonrpc = object.has("jsonrpc") ? object.get("jsonrpc").getAsString() : null;
        if (!"2.0".equals(jsonrpc)) {
            throw new IllegalArgumentException("Only JSON-RPC 2.0 is supported");
        }
        if (!object.has("method") || !object.get("method").isJsonPrimitive()) {
            throw new IllegalArgumentException("Missing JSON-RPC method");
        }

        JsonElement id = object.get("id");
        String method = object.get("method").getAsString();
        JsonObject params = object.has("params") && object.get("params").isJsonObject()
                ? object.getAsJsonObject("params")
                : new JsonObject();

        return new JsonRpcRequest(id, method, params);
    }
}
