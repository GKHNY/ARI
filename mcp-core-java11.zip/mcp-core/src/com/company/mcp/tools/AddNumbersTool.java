package com.company.mcp.tools;

import com.company.mcp.exception.ToolException;
import com.company.mcp.tool.BaseTool;
import com.company.mcp.tool.ToolContext;
import com.company.mcp.tool.ToolRequest;
import com.company.mcp.tool.ToolResponse;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.math.BigDecimal;

public final class AddNumbersTool extends BaseTool {
    @Override
    public String getName() {
        return "add_numbers";
    }

    @Override
    public String getDescription() {
        return "Adds two numeric values named a and b and returns their sum.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject numberProperty = new JsonObject();
        numberProperty.addProperty("type", "number");

        JsonObject properties = new JsonObject();
        properties.add("a", numberProperty.deepCopy());
        properties.add("b", numberProperty.deepCopy());

        JsonArray required = new JsonArray();
        required.add("a");
        required.add("b");

        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        schema.add("properties", properties);
        schema.add("required", required);
        schema.addProperty("additionalProperties", false);
        return schema;
    }

    @Override
    protected ToolResponse executeInternal(ToolRequest request, ToolContext context) throws ToolException {
        BigDecimal a = readDecimal(request, "a");
        BigDecimal b = readDecimal(request, "b");
        return ToolResponse.ok(a.add(b).stripTrailingZeros().toPlainString());
    }

    private BigDecimal readDecimal(ToolRequest request, String key) throws ToolException {
        if (!request.has(key)) {
            throw new ToolException("Missing required argument: " + key);
        }
        try {
            return request.getArguments().get(key).getAsBigDecimal();
        } catch (RuntimeException ex) {
            throw new ToolException("Argument '" + key + "' must be a valid number", ex);
        }
    }
}
