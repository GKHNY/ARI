package com.company.mcp.tools;

import com.company.mcp.exception.ToolException;
import com.company.mcp.tool.BaseTool;
import com.company.mcp.tool.ToolContext;
import com.company.mcp.tool.ToolRequest;
import com.company.mcp.tool.ToolResponse;
import com.google.gson.JsonObject;

public final class HealthCheckTool extends BaseTool {
    @Override
    public String getName() {
        return "mcp_server_health_check";
    }

    @Override
    public String getDescription() {
        return "Checks whether this MCP server is running. Call this tool directly for a server health check.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        schema.add("properties", new JsonObject());
        schema.add("required", new com.google.gson.JsonArray());
        return schema;
    }

    @Override
    protected ToolResponse executeInternal(ToolRequest request, ToolContext context) throws ToolException {
        return ToolResponse.ok("pong");
    }
}
