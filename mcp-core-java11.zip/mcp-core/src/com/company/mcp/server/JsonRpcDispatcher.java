package com.company.mcp.server;

import com.company.mcp.exception.ToolException;
import com.company.mcp.protocol.JsonRpcRequest;
import com.company.mcp.protocol.JsonRpcResponses;
import com.company.mcp.tool.Tool;
import com.company.mcp.tool.ToolContext;
import com.company.mcp.tool.ToolRegistry;
import com.company.mcp.tool.ToolRequest;
import com.company.mcp.tool.ToolResponse;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public final class JsonRpcDispatcher {
    private static final String PROTOCOL_VERSION = "2024-11-05";

    private final ToolRegistry registry;
    private final ToolContext context;

    public JsonRpcDispatcher(ToolRegistry registry, ToolContext context) {
        this.registry = registry;
        this.context = context;
    }

    public JsonObject dispatch(JsonRpcRequest request) {
        String method = request.getMethod();

        if ("notifications/initialized".equals(method)) {
            return null;
        }
        if ("initialize".equals(method)) {
            return JsonRpcResponses.success(request.getId(), handleInitialize());
        }
        if ("tools/list".equals(method)) {
            return JsonRpcResponses.success(request.getId(), handleToolsList());
        }
        if ("tools/call".equals(method)) {
            return handleToolsCall(request);
        }
        if ("ping".equals(method)) {
            return JsonRpcResponses.success(request.getId(), new JsonObject());
        }

        return request.isNotification()
                ? null
                : JsonRpcResponses.error(request.getId(), -32601, "Method not found: " + method);
    }

    private JsonObject handleInitialize() {
        JsonObject capabilities = new JsonObject();
        capabilities.add("tools", new JsonObject());

        JsonObject serverInfo = new JsonObject();
        serverInfo.addProperty("name", "mcp-core");
        serverInfo.addProperty("version", "0.1.0");

        JsonObject result = new JsonObject();
        result.addProperty("protocolVersion", PROTOCOL_VERSION);
        result.add("capabilities", capabilities);
        result.add("serverInfo", serverInfo);
        return result;
    }

    private JsonObject handleToolsList() {
        JsonArray tools = new JsonArray();
        for (Tool tool : registry.getAll()) {
            JsonObject definition = new JsonObject();
            definition.addProperty("name", tool.getName());
            definition.addProperty("description", tool.getDescription());
            definition.add("inputSchema", tool.getInputSchema());
            tools.add(definition);
        }

        JsonObject result = new JsonObject();
        result.add("tools", tools);
        return result;
    }

    private JsonObject handleToolsCall(JsonRpcRequest request) {
        JsonObject params = request.getParams();
        if (!params.has("name")) {
            return JsonRpcResponses.error(request.getId(), -32602, "Missing tool name");
        }

        String name = params.get("name").getAsString();
        Tool tool = registry.get(name);
        if (tool == null) {
            return JsonRpcResponses.error(request.getId(), -32602, "Unknown tool: " + name);
        }

        JsonObject arguments = params.has("arguments") && params.get("arguments").isJsonObject()
                ? params.getAsJsonObject("arguments")
                : new JsonObject();

        try {
            ToolResponse toolResponse = tool.execute(new ToolRequest(arguments), context);
            JsonObject result = toMcpToolResult(toolResponse);
            return JsonRpcResponses.success(request.getId(), result);
        } catch (ToolException ex) {
            return JsonRpcResponses.success(request.getId(), toMcpToolResult(ToolResponse.error(ex.getMessage())));
        } catch (RuntimeException ex) {
            return JsonRpcResponses.error(request.getId(), -32603, "Internal tool error");
        }
    }

    private JsonObject toMcpToolResult(ToolResponse response) {
        JsonObject textContent = new JsonObject();
        textContent.addProperty("type", "text");
        textContent.addProperty("text", response.getMessage());

        JsonArray content = new JsonArray();
        content.add(textContent);

        JsonObject result = new JsonObject();
        result.add("content", content);
        if (!response.isSuccess()) {
            result.addProperty("isError", true);
        }
        return result;
    }
}
