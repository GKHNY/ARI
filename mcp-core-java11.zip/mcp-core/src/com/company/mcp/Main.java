package com.company.mcp;

import com.company.mcp.protocol.JsonRpcParser;
import com.company.mcp.server.JsonRpcDispatcher;
import com.company.mcp.server.McpServer;
import com.company.mcp.tool.ToolContext;
import com.company.mcp.tool.ToolRegistry;
import com.company.mcp.tools.AddNumbersTool;
import com.company.mcp.tools.HealthCheckTool;
import com.google.gson.Gson;

public final class Main {
    private Main() {}

    public static void main(String[] args) throws Exception {
        ToolRegistry registry = new ToolRegistry();
        registry.register(new HealthCheckTool());
        registry.register(new AddNumbersTool());

        ToolContext context = new ToolContext();
        JsonRpcDispatcher dispatcher = new JsonRpcDispatcher(registry, context);
        McpServer server = new McpServer(new JsonRpcParser(), dispatcher, new Gson());
        server.run();
    }
}
