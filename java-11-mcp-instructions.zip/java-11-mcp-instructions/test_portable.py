#!/usr/bin/env python3
"""Headless integration test for the packaged original MCP JAR and Swing adapter."""
import hashlib
import json
import os
from pathlib import Path
import queue
import subprocess
import tempfile
import threading
import zipfile
import build

ROOT = Path(__file__).resolve().parent
HARNESS = """
import integration.ExistingSwingMcpTools;
import integration.McpBootstrap;
public class AdapterHarness {
    public static void main(String[] args) throws Exception {
        McpBootstrap.runStdio(new ExistingSwingMcpTools.TrackService() {
            private double bearing = 50;
            private void check(int id) {
                if (!javax.swing.SwingUtilities.isEventDispatchThread())
                    throw new IllegalStateException("Not on EDT");
                if (id != 1001) throw new IllegalArgumentException("Unknown track");
            }
            public double getBearing(int id) { check(id); return bearing; }
            public void setBearing(int id, double value) { check(id); bearing = value; }
        });
    }
}
"""

def main():
    tools = build.jdk_tools()
    checksums = ROOT / "SHA256SUMS.txt"
    if checksums.exists():
        for line in checksums.read_text().splitlines():
            expected, relative = line.split("  ", 1)
            if relative.startswith("input/"):
                assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected
    with zipfile.ZipFile(ROOT / "lib/java11-mcp.jar") as archive:
        names = archive.namelist()
        assert "com/havelsan/mcp/server/McpServer.class" in names
        assert "com/havelsan/mcp/server/McpHttpServer.class" in names, "HTTP class missing after rebuild"
        assert not any("/example/" in n or n.endswith("/Main.class") for n in names)
        for name in names:
            if name.endswith(".class"):
                assert int.from_bytes(archive.read(name)[6:8], "big") == 55
    with zipfile.ZipFile(ROOT / "dist/swing-track-demo.jar") as archive:
        assert not any(n.startswith("com/havelsan/") for n in archive.namelist())

    with tempfile.TemporaryDirectory(prefix="mcp-adapter-test-") as tmp:
        source = Path(tmp) / "AdapterHarness.java"
        source.write_text(HARNESS, encoding="utf-8")
        build.run([tools["javac"], "--release", "11", "-encoding", "UTF-8", "-cp",
                   ROOT / "lib/*", "-d", tmp, source] + sorted((ROOT / "integration").glob("*.java")))
        cp = os.pathsep.join([tmp, str(ROOT / "lib/*")])
        process = subprocess.Popen([tools["java"], "-Djava.awt.headless=true", "-cp", cp,
                                    "AdapterHarness"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                   text=True, encoding="utf-8")
        responses = queue.Queue()
        def read():
            for line in process.stdout:
                responses.put(line)
        threading.Thread(target=read, daemon=True).start()
        counter = 0
        def rpc(method, params):
            nonlocal counter
            counter += 1
            process.stdin.write(json.dumps(dict(jsonrpc="2.0", id=counter, method=method, params=params)) + "\n")
            process.stdin.flush()
            response = json.loads(responses.get(timeout=10))
            assert response["id"] == counter
            return response
        def call(name, args):
            return rpc("tools/call", {"name": name, "arguments": args})
        try:
            assert rpc("initialize", {"protocolVersion": "2024-11-05",
                "capabilities": {}, "clientInfo": {"name": "test", "version": "1"}})["result"]
            process.stdin.write('{"jsonrpc":"2.0","method":"notifications/initialized"}\n')
            process.stdin.flush()
            assert len(rpc("tools/list", {})["result"]["tools"]) == 2
            result = call("set_track_bearing", {"trackNumber": 1001, "bearing": 60})
            assert result["result"]["content"][0]["text"] == "60.0"
            assert call("get_track_bearing", {"trackNumber": 1001})["result"]["content"][0]["text"] == "60.0"
            assert "error" in call("set_track_bearing", {"trackNumber": 1001, "bearing": 360})
            assert "error" in call("set_track_bearing", {"trackNumber": 9999, "bearing": 60})
            assert call("get_track_bearing", {"trackNumber": 1001})["result"]["content"][0]["text"] == "60.0"
        finally:
            process.stdin.close()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.terminate()
                process.wait(timeout=5)
    print("PASS: original ZIP hash, library separation, Java 11 bytecode, adapter compilation, MCP STDIO, EDT and validation")

if __name__ == "__main__":
    main()
