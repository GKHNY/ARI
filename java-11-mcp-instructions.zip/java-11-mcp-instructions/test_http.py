#!/usr/bin/env python3
"""Tests local HTTP adapter state and shutdown; --gui additionally launches the real Swing demo."""
import argparse
import http.client
import json
import os
from pathlib import Path
import queue
import subprocess
import tempfile
import threading
import time
import zipfile
import build

ROOT = Path(__file__).resolve().parent
HARNESS = """
import integration.ExistingSwingMcpTools;
import integration.McpBootstrap;
import com.havelsan.mcp.server.McpHttpServer;
public class HttpHarness {
    public static void main(String[] args) throws Exception {
        McpHttpServer server = McpBootstrap.startHttp(new ExistingSwingMcpTools.TrackService() {
            private double bearing = 50;
            private void check(int id) {
                if (!javax.swing.SwingUtilities.isEventDispatchThread())
                    throw new IllegalStateException("Not on EDT");
                if (id != 1001) throw new IllegalArgumentException("Unknown track");
            }
            public double getBearing(int id) { check(id); return bearing; }
            public void setBearing(int id, double value) { check(id); bearing = value; }
        }, 0);
        System.out.println(server.getPort());
        try { System.in.read(); } finally { server.stop(); }
    }
}
"""

def request(port, method, params=None, notification=False, path="/mcp", verb="POST", headers=None):
    payload = dict(jsonrpc="2.0", method=method, params=params or {})
    if not notification:
        payload["id"] = 1
    # A new connection on every call proves shared state across connections.
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    try:
        connection.request(verb, path, json.dumps(payload), headers or {"Content-Type": "application/json"})
        response = connection.getresponse()
        body = response.read()
        return response.status, json.loads(body) if body else None
    finally:
        connection.close()

def initialize(port):
    status, response = request(port, "initialize", {"protocolVersion": "2024-11-05",
        "capabilities": {}, "clientInfo": {"name": "http-test", "version": "1"}})
    assert status == 200 and response["result"]
    assert request(port, "notifications/initialized", notification=True) == (202, None)

def call(port, name, arguments):
    status, response = request(port, "tools/call", {"name": name, "arguments": arguments})
    assert status == 200
    return response

def text(response):
    return response["result"]["content"][0]["text"]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gui", action="store_true")
    args = parser.parse_args()
    tools = build.jdk_tools()
    with zipfile.ZipFile(ROOT / "lib/java11-mcp.jar") as archive:
        assert "com/havelsan/mcp/server/McpHttpServer.class" in archive.namelist(), "HTTP class missing"
    with tempfile.TemporaryDirectory(prefix="http-adapter-") as tmp:
        source = Path(tmp) / "HttpHarness.java"
        source.write_text(HARNESS, encoding="utf-8")
        build.run([tools["javac"], "--release", "11", "-encoding", "UTF-8", "-cp", ROOT / "lib/*",
                   "-d", tmp, source] + sorted((ROOT / "integration").glob("*.java")))
        process = subprocess.Popen([tools["java"], "-Djava.awt.headless=true", "-cp",
            os.pathsep.join([tmp, str(ROOT / "lib/*")]), "HttpHarness"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
        lines = queue.Queue()
        threading.Thread(target=lambda: lines.put(process.stdout.readline()), daemon=True).start()
        try:
            port = int(lines.get(timeout=10))
            initialize(port)
            assert len(request(port, "tools/list")[1]["result"]["tools"]) == 2
            assert text(call(port, "set_track_bearing", {"trackNumber": 1001, "bearing": 60})) == "60.0"
            initialize(port)  # a second client shares the same service instance
            assert text(call(port, "get_track_bearing", {"trackNumber": 1001})) == "60.0"
            assert "error" in call(port, "set_track_bearing", {"trackNumber": 1001, "bearing": 360})
            assert "error" in call(port, "set_track_bearing", {"trackNumber": 9999, "bearing": 60})
            assert text(call(port, "get_track_bearing", {"trackNumber": 1001})) == "60.0"
            assert request(port, "ping", verb="GET")[0] == 405
            assert request(port, "ping", path="/mcp-wrong")[0] == 404
            assert request(port, "ping", headers={"Origin": "https://example.invalid"})[0] == 403
            process.stdin.close()
            process.wait(timeout=8)
            assert process.returncode == 0, "HTTP shutdown failed"
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=5)
    print("PASS: HTTP JAR, handshake, independent clients/shared model, EDT, validation, routing and clean shutdown")
    if args.gui:
        import socket
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        process = subprocess.Popen([tools["java"], "-cp",
            os.pathsep.join([str(ROOT / "dist/swing-track-demo.jar"), str(ROOT / "lib/*")]),
            "demo.TrackApp", "--mcp-http", str(port)], stdin=subprocess.DEVNULL)
        try:
            for attempt in range(50):
                if process.poll() is not None:
                    raise RuntimeError("Swing exited before startup")
                try:
                    initialize(port)
                    break
                except OSError:
                    time.sleep(0.1)
            else:
                raise RuntimeError("Swing HTTP startup timeout")
            tracks = json.loads(text(call(port, "list_tracks", {})))
            fields = dict(tracks[0], existingTrackNumber=tracks[0]["trackNumber"], bearing=60)
            assert json.loads(text(call(port, "update_track", fields)))["bearing"] == 60
            assert json.loads(text(call(port, "list_tracks", {})))[0]["bearing"] == 60
            import sys
            updated = subprocess.check_output([sys.executable, str(ROOT / "http_client.py"),
                "--port", str(port), "--track", str(tracks[0]["trackNumber"]), "--bearing", "75"], text=True)
            assert json.loads(updated)["bearing"] == 75
            listed = subprocess.check_output([sys.executable, str(ROOT / "http_client.py"),
                "--port", str(port), "--list"], text=True)
            assert json.loads(listed)[0]["bearing"] == 75
            print("PASS: actual Swing demo HTTP mode, closed stdin and two separate client processes")
        finally:
            process.terminate()
            process.wait(timeout=10)

if __name__ == "__main__":
    main()
