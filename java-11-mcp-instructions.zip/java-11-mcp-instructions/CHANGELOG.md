# Değişiklikler

## 1.2 — 2026-09-23

- Varsayılan derleme HTTP içeren kaynak ZIP'ini kullanır; yeniden derleme HTTP desteğini korur.
- Paket içindeki Swing demosuna HTTP modu ve mevcut servis için HTTP başlatıcısı eklendi.
- Ayrı HTTP istemcileriyle ortak model, EDT, doğrulama ve temiz kapanış testleri tamamlandı.
- HTTP sunucusu loopback üzerinde dinler; executor kapanışı ve istek kontrolleri düzenlendi.
- Başka demo klasörüne bağımlı olmayan HTTP kullanım rehberi eklendi.
- minReqForOIUpdate.md: mevcut ComboBox/setDisplayValue için minimum tek-tool örneği.
- ZIP'ten temiz klasöre çıkarıp Java 11 ile derleme ve STDIO/HTTP testleri doğrulandı.

Orijinal java11-mcp-annotation-final.zip değiştirilmedi.
Bu sürüm paket sürümüdür; orijinal dispatcher protokol/serverInfo sürümünü değiştirmez.
