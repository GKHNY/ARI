#!/usr/bin/env python3
"""A small local HTTP JSON-RPC client, independent of any desktop MCP application."""
import argparse
import json
import urllib.request

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--track", type=int, default=1001)
    parser.add_argument("--bearing", type=float)
    args = parser.parse_args()
    url = "http://127.0.0.1:%d/mcp" % args.port
    counter = 0
    def rpc(method, params, notification=False):
        nonlocal counter
        counter += 1
        payload = dict(jsonrpc="2.0", method=method, params=params)
        if not notification:
            payload["id"] = counter
        request = urllib.request.Request(url, json.dumps(payload).encode("utf-8"),
                    {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"})
        # Do not route local requests through a system proxy.
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request, timeout=10) as response:
            body = response.read()
        if not body:
            return None
        result = json.loads(body)
        if "error" in result:
            raise RuntimeError(result["error"])
        return result["result"]
    rpc("initialize", {"protocolVersion": "2024-11-05", "capabilities": {},
                      "clientInfo": {"name": "portable-http-client", "version": "1"}})
    rpc("notifications/initialized", {}, True)
    def call(name, arguments):
        result = rpc("tools/call", {"name": name, "arguments": arguments})
        if result.get("isError"):
            raise RuntimeError(result)
        return json.loads(result["content"][0]["text"])
    tracks = call("list_tracks", {})
    if args.bearing is not None:
        track = next((t for t in tracks if t["trackNumber"] == args.track), None)
        if track is None:
            raise RuntimeError("Track not found: %s" % args.track)
        fields = dict(track, existingTrackNumber=args.track, bearing=args.bearing)
        print(json.dumps(call("update_track", fields), ensure_ascii=False, indent=2))
    else:
        print(json.dumps(tracks, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
