# Doğrulama — güncel paket

Java 11 ile Linux ARM64 üzerinde kontrol edildi. Windows/macOS için taşınabilir scriptler
ve komutlar bulunur; bu iki sistemde çalıştırma testi yapılmadı.

- Varsayılan build.py all artık HTTP'li kaynak ZIP'ini kullanır.
- Hazır JAR ve yeniden üretilen JAR hem McpServer hem McpHttpServer içerir.
- Orijinal ZIP değiştirilmedi. HTTP uzantısı ayrı with-http ZIP'inde saklanır.
- Demo JAR MCP sınıflarını içine kopyalamaz; lib/java11-mcp.jar ve Gson'a bağımlıdır.
- Java class bytecode sürümü 55 (Java 11).
- test_portable.py: STDIO handshake, araç listesi, bearing güncelleme/okuma, EDT ve hatalı giriş.
- test_http.py: HTTP handshake, ayrı bağlantılardan aynı model, EDT, hatalı giriş,
  bildirim 202, yanlış endpoint 404, GET 405, Origin reddi ve temiz kapanış.
- test_http.py --gui: paketteki gerçek Swing demosu HTTP modunda, kapalı stdin ile açıldı;
  MCP üzerinden bearing 60 yapıldı ve yeniden okunarak doğrulandı.
- HTTP istemci scripti ayrı süreçlerden güncelleme ve listeleme için test edilir.
- Teslim ZIP'i ayrı, adında boşluk bulunan klasöre açılarak yeniden derleme ve test yapılır.

Sunucunun HTTP uzantısında yapılan düzenlemeler:
- Yalnızca 127.0.0.1 üzerinde dinleme.
- stop() içinde executor kaynaklarını kapatma.
- Gerçekten stateless çalışma; kullanılmayan session ID üretiminin kaldırılması.
- Tam endpoint yolu kontrolü, tarayıcı Origin reddi ve 1 MiB istek sınırı.
- Rastgele port ile test için getPort() desteği.

Bu testler bütün MCP istemcileriyle/protokol sürümleriyle uyumluluğu garanti etmez.
Dispatcher'ın bildirdiği protokol sürümü orijinal 2024-11-05 olarak korunmuştur.
Windows/macOS üzerinde ve kendi uygulamanın gerçek servisleriyle kabul testi ayrıca yapılmalıdır.

SHA256SUMS.txt teslim edilen iki ZIP ve üç JAR'ın dosya özetlerini içerir.
Yeniden derlemede JAR zaman damgaları nedeniyle hash değişebilir; kaynak ZIP'ler sabit kalır.
