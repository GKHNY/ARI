# Doğrulama

Bu paket Linux ARM64 üzerinde JDK 11 ile doğrulandı.

- Orijinal ZIP ile input altındaki kopya byte düzeyinde aynı.
- build.py all doğrudan ZIP içinden MCP kütüphanesini ve Swing demo JAR dosyasını üretti.
- Kütüphanedeki class dosyalarının bytecode major version değeri 55 (Java 11).
- Demo JAR içinde com/havelsan MCP sınıfları yok; ayrı kütüphane kullanılıyor.
- integration klasöründeki iki Java sınıfı Java 11 ile derlendi.
- Headless testte gerçek STDIO sunucusuyla initialize, tools/list, bearing okuma/yazma çalıştı.
- Adapter'ın EDT üzerinde çalıştığı doğrulandı.
- 360 derece ve olmayan iz çağrıları reddedildi; önceki değer korundu.
- README içindeki Linux ve Windows istemci yapılandırmaları JSON olarak ayrıştırıldı.

Windows ve macOS üzerinde çalıştırma testi yapılmadı. Scriptler bu sistemlere uygun yol,
Java araç adı ve classpath ayırıcılarını kullanır; hedef makinede test_portable.py çalıştırılmalıdır.

Buradaki headless adapter testi gerçek uygulamanızın özel servislerini veya ekranının
model değişikliğine tepkisini test etmez. Bunları entegrasyon rehberindeki kabul testiyle kontrol edin.

Önceki canlı Swing denemesi ayrı swing-track-demo projesinde Java 11 ve aynı MCP JAR
yaklaşımıyla çalıştırıldı; MCP üzerinden 1001 numaralı izin bearing değeri 60 yapıldı.

JAR dosyaları yeniden derlendiğinde paket zaman damgaları nedeniyle SHA-256 değişebilir.
SHA256SUMS.txt teslim edilen dosyaların özetidir; kaynak ZIP hash'i sabit kalmalıdır.
