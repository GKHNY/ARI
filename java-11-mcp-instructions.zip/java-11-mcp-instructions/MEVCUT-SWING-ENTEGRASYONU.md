# Zaten yazılmış Swing uygulamasına entegrasyon

## Hedef yapı

```text
MCP istemcisi
    │ STDIO JSON-RPC
    ▼
Mevcut Swing uygulamasının Java süreci
    ├── java11-mcp.jar: dispatcher → registry → annotation'lı araç
    ├── uygulamana ait adapter: girdi kontrolü → EDT'ye geçiş
    └── mevcut servis/model instance'ı → model değişiklik olayı → mevcut pencere
```

JAR'ı classpath'e eklemek tek başına metotları otomatik açmaz. Uygulamanın başlangıcına MCP başlatma kodu ve kullanılacak araçlara annotation/adapter eklemelisin. Kütüphane kaynaklarını uygulamanın src klasörüne taşıma.

## 1. Bağımlılıkları ekle

Uygulamanın `lib` klasörüne şu iki JAR'ı koy:

- `java11-mcp.jar`
- `gson-2.8.0.jar`

IDE'de ikisini de proje kütüphanesi olarak hem compile hem runtime classpath'ine ekle.
Uygulaman zaten Gson kullanıyorsa classpath'te iki farklı Gson sürümü bırakma; mevcut sürümle uyumluluğu test et.
JAR'ı eklemek uygulamanın diğer bağımlılıklarının yerine geçmez.

Maven kullanıyorsan örnek yerel kurulum:

```bash
mvn install:install-file -Dfile=lib/java11-mcp.jar -DgroupId=local.mcp -DartifactId=java11-mcp -Dversion=1.0.0 -Dpackaging=jar -DgeneratePom=true
```

Uygulama POM'una:

```xml
<dependencies>
  <dependency>
    <groupId>local.mcp</groupId>
    <artifactId>java11-mcp</artifactId>
    <version>1.0.0</version>
  </dependency>
  <dependency>
    <groupId>com.google.code.gson</groupId>
    <artifactId>gson</artifactId>
    <version>2.8.0</version>
  </dependency>
</dependencies>
```

Buradaki `local.mcp` örnek yerel koordinattır; yayımlanmış bir Maven Central paketi değildir.
Yerel kurulum her geliştiricinin makinesinde yapılmalı veya JAR kurumun artifact deposuna yayımlanmalıdır.
Gson bağımlılığını ayrıca tanımlıyoruz; üretilen basit POM'a transitif bağımlılık yazılmıyor.

## 2. Mevcut servis için adapter oluştur

`integration/ExistingSwingMcpTools.java` dosyası uygulamana ait bir örnektir; kütüphane kodu değildir.
Bu adapter iki araç tanımlar:

- `get_track_bearing(trackNumber)`
- `set_track_bearing(trackNumber, bearing)`

`TrackService` arayüzünü mevcut modeline uyarlarsın. Örneğin aşağıdaki **yer tutucu** isimleri kendi uygulamandaki gerçek sınıf/metotlarla değiştir:

```java
ExistingSwingMcpTools.TrackService bridge =
    new ExistingSwingMcpTools.TrackService() {
        public double getBearing(int trackNumber) {
            return existingTrackModel.findRequired(trackNumber).getBearing();
        }

        public void setBearing(int trackNumber, double bearing) {
            existingTrackModel.updateBearing(trackNumber, bearing);
            // updateBearing mevcut iş kurallarını uygulamalı ve
            // fireTableRowsUpdated / property-change benzeri olayı yayımlamalı.
        }
    };
```

`existingTrackModel`, pencerenin kullandığı **aynı nesne** olmalı. Araç içinde yeni model veya yeni servis oluşturursan görünmeyen başka bir veri kümesini değiştirirsin.

Tercihen düğmenin ActionListener'ına doğrudan tıklatmak yerine, düğmenin kullandığı servis metodunu çağır.
Yalnızca JTextField.setText yapmak uygulamanın asıl modelini kaydetmeyebilir.
Alanları kalıcı saklamak gerekiyorsa MCP de mevcut uygulamanın save/commit akışını kullanmalı.

## 3. Başlatma akışına bağla

`integration/McpBootstrap.java` kütüphaneyi şu şekilde bağlar:

```java
Gson gson = new GsonBuilder().disableHtmlEscaping().create();
ToolRegistry registry = new ToolRegistry(gson)
    .register(new ExistingSwingMcpTools(existingService));
McpServer server = new McpServer(new JsonRpcDispatcher(gson, registry));
server.runStdio();
```

Uygulamanın main akışı için aşağıdaki **uyarlanacak taslak** kullanılabilir:

```java
public static void main(String[] args) throws Exception {
    boolean mcp = java.util.Arrays.asList(args).contains("--mcp");
    java.util.concurrent.atomic.AtomicReference<ExistingSwingMcpTools.TrackService> ref =
        new java.util.concurrent.atomic.AtomicReference<>();

    javax.swing.SwingUtilities.invokeAndWait(() -> {
        // Mevcut başlangıç kodun:
        // 1. Mevcut model/servisleri oluştur.
        // 2. Mevcut pencereyi bu servislerle aç.
        // 3. Aynı servise bağlı bridge nesnesini ref.set(bridge) ile kaydet.
    });

    if (mcp) {
        McpBootstrap.runStdio(ref.get()); // main thread üzerinde; EDT üzerinde değil
    }
}
```

Taslak tek başına derlenecek tam uygulama değildir; mevcut başlangıç kodun ve bridge ile doldurulmalıdır.
Demo kaynak dosyası ise eksiksiz derlenebilir örnektir.

Mevcut uygulamanın main thread'ini başka işler için kullanıyorsan MCP döngüsünü tek bir ayrı thread üzerinde çalıştırabilirsin:

```java
Thread mcpThread = new Thread(() -> {
    try {
        McpBootstrap.runStdio(bridge);
    } catch (Exception e) {
        e.printStackTrace(System.err);
    }
}, "mcp-stdio");
mcpThread.setDaemon(true);
mcpThread.start();
```

Bu alternatifi uygulama zaten açık ve Swing yaşam döngüsü devam ediyorsa kullan. Aynı stdin'i okuyan iki MCP döngüsü başlatma.
Uygulama stdin'i başka bir konsol menüsü için okuyorsa o okuyucuyu MCP modunda devre dışı bırak.

MCP bağlantısı kapanınca uygulamanın kapanıp kapanmayacağına açıkça karar ver.
Bizim demo STDIO EOF'ta pencereleri kapatır. Yukarıdaki mevcut uygulama başlatıcısı ise runStdio döndüğünde kendiliğinden pencere kapatmaz.
Pencere kapanırken de uygulamanın var olan kapanış akışını kullan; yalnızca MCP için mevcut veri kaydetme adımlarını atlama.

## 4. Swing iş parçacığı kuralı

Adapter'ın `onEdt` yardımcısı model/UI işlemini EDT üzerinde çalıştırır ve tamamlanmasını bekler.
Böylece sunucu yanıt verdiğinde model güncellemesi tamamlanmıştır.

- runStdio: EDT dışında; bloklayan okuma döngüsüdür.
- Kısa model okuma/yazma ve UI olayları: EDT üzerinde.
- Uzun ağ/veritabanı işi: mevcut worker/service akışında; EDT'yi kilitleme.
- EDT'den zaten çağrılmışsa yardımcımız invokeAndWait yapmaz; doğrudan çalıştırır.
- EDT üzerinde gelecekteki MCP işinin bitmesini bekleme; karşılıklı bekleme oluşturabilirsin.
- JSON'a bütün JFrame/JTable nesnesini döndürme; küçük DTO veya primitive sonuç döndür.

## 5. Annotation'ları mevcut metotlara doğrudan koyabilir miyim?

Evet:

```java
@McpTool(name = "set_track_bearing", description = "Updates bearing in degrees")
public double setBearing(
    @McpParam(name = "trackNumber") int trackNumber,
    @McpParam(name = "bearing") double bearing) {
    // mevcut iş kuralı ve model güncellemesi
    return bearing;
}
```

Bu sadece annotation kullanımını gösterir; yorum yerine gerçek güncelleme gerekir.
Ardından `register(existingService)` yaparsın. Kütüphane Swing EDT geçişini otomatik yapmaz.
Mevcut servis zaten thread-safe ve UI güncellemelerini doğru yönetiyorsa doğrudan kayıt uygundur;
aksi halde bu paketteki adapter yaklaşımı daha açık bir entegrasyon sağlar.

## 6. Aynı çalışan pencereye HTTP ile bağlanma

STDIO'da istemci süreci başlatır; bağımsız açık bir pencereye sonradan bağlanmaz.
HTTP'de uygulamanın kendi JVM'i bir endpoint açar ve farklı istemciler aynı modele erişir.

Bu pakette hazır başlatıcı vardır:

```java
com.havelsan.mcp.server.McpHttpServer http =
    McpBootstrap.startHttp(bridge, 8765);
// Uygulamanın var olan kapanış akışında:
http.stop();
```

bridge, yukarıdaki gibi pencerenin gerçek modeline bağlı adapter olmalıdır.
Başlatma çağrısı hemen döner; UI değişiklikleri adapter üzerinden EDT'ye taşınır.
Ayrıntılı başlatma/istemci komutları ve protokol kapsamı bu paketin
[HTTP-KULLANIMI.md](HTTP-KULLANIMI.md) dosyasındadır.
Başka bir swing-track-demo klasörüne ihtiyaç yoktur.

## 7. Kabul testi

1. JAR'ları çalışma classpath'ine ekle, uygulamayı MCP modunda aç.
2. initialize ve notifications/initialized mesajlarını gönder.
3. tools/list içinde get_track_bearing ve set_track_bearing'i gör.
4. Uygulamada var olan bir iz için çağır:

```json
{"jsonrpc":"2.0","id":10,"method":"tools/call","params":{"name":"set_track_bearing","arguments":{"trackNumber":1001,"bearing":60}}}
{"jsonrpc":"2.0","id":11,"method":"tools/call","params":{"name":"get_track_bearing","arguments":{"trackNumber":1001}}}
```

5. Hem okuma sonucu hem ekran 60 göstermeli.
6. UI'dan değeri değiştir; get_track_bearing yeni değeri görmeli.
7. Olmayan iz ve 360/negatif bearing için hata almalı, model değişmemeli.
8. Pencere kapanışı ve bağlantı kopmasını mevcut uygulamanın yaşam döngüsüyle test et.

Yalnızca JAR eklemekle bütün eski uygulamanın metotları araç olmaz. Hangi fonksiyonların açılacağını, parametreleri ve iş kurallarını senin adapter'ın belirler.
