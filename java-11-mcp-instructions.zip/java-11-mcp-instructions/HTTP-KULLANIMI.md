# HTTP ile aynı Swing penceresini yönetme

Bu rehberdeki bütün dosyalar bu paketin içindedir. Başka bir swing-track-demo klasörü gerekmez.

## Derle ve aç

Önce JAVA_HOME'u makinenin JDK 11 kurulumuna ayarla. Paket klasöründe:

Linux/macOS:
```bash
python3 build.py all
python3 build.py http --port 8765
```

Windows PowerShell:
```powershell
py -3 build.py all
py -3 build.py http --port 8765
```

Hazır JAR ile Python kullanmadan:
```bash
# Linux/macOS
java -cp "dist/swing-track-demo.jar:lib/*" demo.TrackApp --mcp-http 8765
```

```powershell
# Windows
java -cp "dist/swing-track-demo.jar;lib/*" demo.TrackApp --mcp-http 8765
```

Tek bir Swing penceresi açılır; endpoint `http://127.0.0.1:8765/mcp` olur.
STDIO modunun aksine stdin kapansa da HTTP penceresi çalışmaya devam eder.
İstemciler yeni Swing süreçleri başlatmadan bu adrese bağlanır.
Pencere kapatılınca bu demo süreci ve HTTP sunucusu kapanır. Port doluysa başka port seç.

## İki ayrı terminalden dene

İkinci terminalde paket klasörüne geç:
```bash
python3 http_client.py --port 8765 --track 1001 --bearing 60
```

Üçüncü terminalde:
```bash
python3 http_client.py --port 8765 --list
```

Windows'ta `python3` yerine `py -3` kullan.
İkinci komut, birinci komutun değiştirdiği 60 değerini görür.
Bu istemci yalnızca demodaki list_tracks/update_track araçlarını kullanır; adapter örneğindeki
get_track_bearing/set_track_bearing araçları farklı isimlerdir.

Demo update_track bütün alanları istediği için istemci önce izi okur, bearing'i değiştirir
ve diğer alanları koruyarak gönderir. Eşzamanlı düzenlemede bu okuma/yazma atomik değildir;
mevcut uygulamada tek alan değiştiren set_track_bearing gibi araçlar tercih edilebilir.

## Mevcut uygulama

`integration/McpBootstrap.java` dosyasında hazır bir başlatıcı vardır:

```java
McpHttpServer http = McpBootstrap.startHttp(bridge, 8765);
// bridge: pencerenin kullandığı gerçek servis/model nesnesine bağlı adapter.
// Uygulamanın kapanış akışında:
http.stop();
```

startHttp dönünce HTTP arka planda dinler. Aynı dispatcher ve servis bütün bağlantılara hizmet verir.
Kapanışta stop çağır; bu yöntem HTTP sunucusuyla executor iş parçacıklarını birlikte kapatır.
Bu kod mevcut uygulamanın içine eklenmelidir; başka JVM'deki modele reflection ile erişim sağlamaz.

## İstemci ve protokol kapsamı

HTTP destekleyen MCP istemcisinde URL olarak `http://127.0.0.1:8765/mcp` kullan.
Alan adları ve kayıt komutu istemciye göre değişir.
Bu paketteki http_client.py ile bağımsız olarak deneme yapabilirsin.

Bu küçük HTTP taşıması aynı JsonRpcDispatcher üzerinden POST JSON-RPC işler.
JSON yanıtı döndürür, bildirimlere 202 verir; GET/SSE sunmaz (405).
Oturum tutmaz ve Mcp-Session-Id üretmez. Dispatcher orijinal `2024-11-05` sürümünü bildirir.
Bütün Streamable HTTP sürümleri veya bütün masaüstü istemcileriyle tam uyumluluk iddiası yoktur;
kullanacağın istemciyle bağlantı testi yap. Buradaki testler doğrudan HTTP/JSON-RPC davranışını doğrular.

Endpoint yalnızca 127.0.0.1 üzerinde dinler; farklı bilgisayarlardan erişim sunmaz.
Tarayıcı Origin başlığı olan çağrılar reddedilir. Bu yerel kullanım örneğinde kimlik doğrulama yoktur;
aynı makinede endpoint'e erişebilen süreçler araçları çağırabilir.

## Testler

```bash
python3 test_portable.py
python3 test_http.py
# Grafik masaüstünde geçici gerçek Swing penceresi de açarak:
python3 test_http.py --gui
```

Windows'ta `py -3` kullan. İlk iki test grafik ekran gerektirmez.
HTTP testi bağımsız bağlantılarla ortak state, EDT, hatalı bearing/iz, endpoint yolu,
bildirimler ve temiz kapanışı doğrular. --gui gerçek demo sürecini açıp listeleme,
bearing güncelleme ve tekrar okumayı test eder; ekranın görüntüsünü incelemez.
