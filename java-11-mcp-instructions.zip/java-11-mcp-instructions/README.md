# Java 11 MCP: ZIP → JAR → Swing entegrasyonu

Bu paket, senin `java11-mcp-annotation-final.zip` dosyanı **kaynaklarını değiştirmeden bir kütüphane JAR'ına** dönüştürür. Swing uygulaması MCP kaynaklarını içine kopyalamaz; JAR'a bağımlı olur.

GB10, NVIDIA, CUDA, GPU veya yerel yapay zekâ modeli gerekmez. Windows/Linux/macOS üzerinde çalıştırılabilir. Hedef bilgisayarın işletim sistemi ve işlemcisine uygun **JDK 11** kullan: örneğin Intel/AMD için x64, ARM için ARM64. Buradaki GB10'un ARM64 JDK klasörünü başka mimariye taşıma. Java kaynakları ve bu projede üretilen JAR'lar mimariye özel değildir.

## Paket içeriği

- `input/java11-mcp-annotation-final.zip`: Senin ZIP'inin değiştirilmemiş kopyası.
- `lib/gson-2.8.0.jar`: Orijinal projenin kullandığı ayrı bağımlılık.
- `build.py`: Windows/Linux/macOS için ortak derleme ve çalıştırma scripti. Python 3 standart kütüphanesini kullanır; paket kurulumu veya ağ bağlantısı gerektirmez.
- `lib/java11-mcp.jar`: ZIP'ten üretilen MCP kütüphanesi.
- `example/src/demo/TrackApp.java`: Birlikte denediğimiz Java 11 Swing uygulaması.
- `dist/swing-track-demo.jar`: Derlenmiş Swing örneği; MCP sınıflarını içermez.
- `integration/`: Mevcut Swing uygulamasına uyarlanacak küçük adapter ve başlatıcı.
- `MEVCUT-SWING-ENTEGRASYONU.md`: Entegrasyonun ayrıntıları.
- `test_portable.py`: Grafik ekran açmadan JAR ve STDIO entegrasyonunu kontrol eder.
- `SHA256SUMS.txt`: ZIP, Gson ve üretilen JAR dosyalarının SHA-256 değerleri.

JAR'lar bu pakette hazır bulunur; istersen scriptle yeniden üret. Kaynak ZIP de bulunduğundan süreç tekrarlanabilir. JDK ve Python pakete dahil değildir.

## 1. Java 11'i seç

JRE yeterli değildir; derleme için `javac` ve `jar` içeren JDK gerekir.

Linux/macOS Bash — örnek yolu kendi JDK kurulumunla değiştir:

```bash
export JAVA_HOME="/path/to/jdk-11"
export PATH="$JAVA_HOME/bin:$PATH"
java -version
javac -version
```

Windows PowerShell — yolu kendi JDK kurulumunla değiştir:

```powershell
$env:JAVA_HOME = 'C:\Java\jdk-11'
$env:Path = "$env:JAVA_HOME\bin;$env:Path"
java -version
javac -version
```

Her ikisi de 11 göstermeli. Script JAVA_HOME tanımlıysa oradaki araçları, değilse PATH'teki araçları kullanır; Java 8 gibi yanlış sürümde açıklayıcı hata verir. Bu oturumluk ayarlar sistem kurulumunu değiştirmez.

## 2. ZIP'ten kütüphane JAR'ı üret

Terminali bu README'nin bulunduğu klasörde aç.

Linux/macOS:
```bash
python3 build.py library
```

Windows:
```powershell
py -3 build.py library
```

Kendi ZIP ve Gson dosyaların başka yerdeyse:

```bash
python3 build.py library --zip "/path/java11-mcp-annotation-final.zip" --gson "/path/gson-2.8.0.jar"
```

Windows'ta aynı argümanları `py -3` ile ve Windows yollarıyla kullan.

Scriptin yaptığı:
1. ZIP içinden yalnızca `annotation`, `core`, `rpc`, `server` paketlerinin Java kaynaklarını geçici klasöre okur.
2. `javac --release 11 -encoding UTF-8 -parameters` ile, Gson derleme bağımlılığı kullanarak derler.
3. Derlenen sınıfları `lib/java11-mcp.jar` içine paketler.
4. Geçici kaynakları temizler. Orijinal ZIP'e yazmaz.

`Main.java` ve `example/ExistingApplicationFunctions.java` kütüphaneye dahil edilmez.
Gson JAR içine gömülmez; çalıştırırken iki JAR da classpath'te bulunmalı.

Burada ilk yaptığımız işlem de aynıydı: açılmış ZIP'teki dört paketi Java 11 ile derleyip `jar --create` ile paketledik. Bu script o işlemi doğrudan ZIP üzerinden taşınabilir hale getirir.

## 3. Swing örneğini derle ve çalıştır

Linux/macOS:
```bash
python3 build.py all
python3 build.py run
```

Windows:
```powershell
py -3 build.py all
py -3 build.py run
```

`all` hem kütüphaneyi hem örneği derler. Yalnızca uygulamayı yeniden derlemek için `demo` kullan.
Tablodan iz seç, sağdaki alanları değiştir, Kaydet'e bas. Yeni iz ile kayıt ekle.
Enlem/boylam derece; bearing 0 dahil 360 hariç derece; range deniz mili.
Tipler Kara, Deniz, Hava. Değerler bellekte tutulur; yeniden başlatınca örnek veriler yüklenir.

Python olmadan, hazır JAR'larla:

Linux/macOS:
```bash
java -cp "dist/swing-track-demo.jar:lib/*" demo.TrackApp
```

Windows:
```powershell
java -cp "dist/swing-track-demo.jar;lib/*" demo.TrackApp
```

Buradaki `java` da Java 11 olmalı. Classpath ayırıcı Linux/macOS'ta `:`, Windows'ta `;` olur.

## 4. MCP modunda başlat ve bearing değiştir

Normal örnek pencereyi kapat, sonra:

```bash
python3 build.py mcp
```

Windows: `py -3 build.py mcp`. Ya da yukarıdaki doğrudan Java komutunun sonuna `--mcp` ekle.

Açılan **aynı pencere** artık STDIO üzerinden MCP çağrılarını alır. Terminale aşağıdaki mesajları sırayla, her birini tek satır olarak gönder:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"manual-test","version":"1.0"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"list_tracks","arguments":{}}}
{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"update_track","arguments":{"existingTrackNumber":1001,"trackNumber":1001,"latitude":39.9334,"longitude":32.8597,"bearing":60,"rangeNm":12.5,"trackType":"KARA"}}}
```

1001 numaralı izin bearing'i 60° olur. Son çağrı **tüm alanları gönderir**; yalnızca bearing değiştirirken önce `list_tracks` ile mevcut değerleri okuyup diğer alanları koru. Mevcut uygulama adapter örneği daha dar bir `set_track_bearing` aracı sunar; onda yalnızca iz numarası ve bearing gerekir.

Terminalin mesajı ekranda göstermesi sunucunun yanıtı değildir. Başarıyı aynı `id` ile dönen `result` ve `isError:false` yanıtından kontrol et.
STDIO kapandığında bu demo MCP modunda pencerelerini kapatır.

## 5. Bir MCP istemcisine bağlama

İstemcinin STDIO sunucu ayarına **Java 11'in mutlak yolunu**, classpath'i ve main sınıfını gir.
İstemci süreç başlatır; bu süreç Swing penceresini açar. STDIO port numarası veya HTTP URL'si kullanmaz.

Genel command/args örneği (üst düzey yapı istemciye göre değişebilir):

```json
{
  "command": "/absolute/path/jdk-11/bin/java",
  "args": [
    "-cp",
    "/absolute/path/java-11-mcp-instructions/dist/swing-track-demo.jar:/absolute/path/java-11-mcp-instructions/lib/*",
    "demo.TrackApp",
    "--mcp"
  ]
}
```

Windows örneği:

```json
{
  "command": "C:\\Java\\jdk-11\\bin\\java.exe",
  "args": [
    "-cp",
    "C:\\java-11-mcp-instructions\\dist\\swing-track-demo.jar;C:\\java-11-mcp-instructions\\lib\\*",
    "demo.TrackApp",
    "--mcp"
  ]
}
```

Mutlak yollar kullan; çalışma klasörüne güvenme. İstemciyi kullanıcının grafik masaüstü oturumunda çalıştır.
Başlatma scripti yalnızca süreci açar; değer değişikliği MCP `tools/call` çağrısıyla olur.
Bu sohbette de bir terminal oturumundan gerçek STDIO MCP mesajları gönderdik; istemcinin kalıcı MCP kayıt ayarını değiştirmedik.

## 6. Kontrol ve sorun giderme

```bash
python3 test_portable.py
jar tf lib/java11-mcp.jar
```

Windows'ta test için `py -3 test_portable.py`.
Test JAR paketlerini, Java 11 bytecode sürümünü, ZIP'in değişmediğini ve adapter üzerinden STDIO bearing güncellemesini denetler; ekran açmaz.

- `javac bulunamadı`: JRE yerine JDK 11 seç.
- `UnsupportedClassVersionError`: Uygulamayı Java 8 ile açıyor olabilirsin; `java -version` ve JAVA_HOME'u kontrol et.
- `NoClassDefFoundError: com/google/gson/...`: Gson çalışma classpath'inde yok.
- `NoClassDefFoundError: com/havelsan/mcp/...`: MCP JAR çalışma classpath'inde yok.
- `HeadlessException` / X11 bağlantı hatası: Swing için grafik masaüstü gerekir. Linux'ta doğru DISPLAY ve oturum erişimini kullan; başsız SSH oturumunda pencere kendiliğinden görünmez.
- JSON yanıtlarının arasına log giriyor: stdout yalnızca MCP için ayrılmalı; logları stderr veya dosyaya yönlendir.
- UI donuyor: `runStdio()` EDT üzerinde çalıştırılmış olabilir.
- Değer değişiyor ama ekran değişmiyor: Farklı model nesnesi kullanılıyor veya model değişiklik olayı yayımlanmıyor.
- Araç görünmüyor: Nesne `register(instance)` ile kaydedilmeli; bu kütüphane `getDeclaredMethods()` kullandığı için annotation doğrudan kaydedilen sınıfın metodunda bulunmalı.
- Bağlantı kurulmuyor: Bu ZIP sunucusu `2024-11-05` protokol sürümünü bildirir; farklı istemcilerle uyumluluk ayrıca denenmelidir.

Bu çalışma orijinal küçük MCP örneğini kütüphane olarak paketler; bütün MCP protokol özelliklerini eklemez.
Yerel izleme/deneme senaryosu için hazırlanmıştır. Orijinal hata işleme ve generic parametre şeması sınırlamaları korunur.
