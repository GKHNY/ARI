package demo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.havelsan.mcp.annotation.McpParam;
import com.havelsan.mcp.annotation.McpTool;
import com.havelsan.mcp.core.ToolRegistry;
import com.havelsan.mcp.rpc.JsonRpcDispatcher;
import com.havelsan.mcp.server.McpServer;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public final class TrackApp {
    public enum TrackType { KARA, DENIZ, HAVA }

    public static final class Track {
        public final int trackNumber;
        public final double latitude, longitude, bearing, rangeNm;
        public final TrackType trackType;
        Track(int number, double lat, double lon, double bearing, double range, TrackType type) {
            if (number <= 0) throw new IllegalArgumentException("İz numarası pozitif olmalı.");
            check(lat, -90, 90, "Enlem");
            check(lon, -180, 180, "Boylam");
            check(bearing, 0, 360, "Bearing");
            if (bearing == 360) throw new IllegalArgumentException("Bearing 360'tan küçük olmalı.");
            if (!Double.isFinite(range) || range < 0) throw new IllegalArgumentException("Range sıfır veya pozitif olmalı.");
            if (type == null) throw new IllegalArgumentException("İz tipi gerekli.");
            trackNumber = number; latitude = lat; longitude = lon;
            this.bearing = bearing; rangeNm = range; trackType = type;
        }
        private static void check(double value, double min, double max, String label) {
            if (!Double.isFinite(value) || value < min || value > max)
                throw new IllegalArgumentException(label + " " + min + " ile " + max + " arasında olmalı.");
        }
    }

    public static final class TrackModel extends AbstractTableModel {
        private final List<Track> tracks = new ArrayList<>();
        private final String[] columns = {"İz numarası", "Enlem (°)", "Boylam (°)", "Bearing (°)", "Range (NM)", "İz tipi"};
        public int getRowCount() { return tracks.size(); }
        public int getColumnCount() { return columns.length; }
        public String getColumnName(int column) { return columns[column]; }
        public Object getValueAt(int row, int col) {
            Track t = tracks.get(row);
            switch (col) {
                case 0: return t.trackNumber;
                case 1: return t.latitude;
                case 2: return t.longitude;
                case 3: return t.bearing;
                case 4: return t.rangeNm;
                default: return label(t.trackType);
            }
        }
        public Class<?> getColumnClass(int col) { return col == 0 ? Integer.class : col == 5 ? String.class : Double.class; }
        int find(int number) {
            for (int i = 0; i < tracks.size(); i++) if (tracks.get(i).trackNumber == number) return i;
            return -1;
        }
        Track save(Integer oldNumber, Track track) {
            if (!SwingUtilities.isEventDispatchThread()) throw new IllegalStateException("EDT gerekli");
            int row = oldNumber == null ? -1 : find(oldNumber);
            if (oldNumber != null && row < 0) throw new IllegalArgumentException("İz bulunamadı: " + oldNumber);
            int duplicate = find(track.trackNumber);
            if (duplicate >= 0 && duplicate != row) throw new IllegalArgumentException("Bu iz numarası zaten var.");
            if (row < 0) { tracks.add(track); fireTableRowsInserted(tracks.size()-1, tracks.size()-1); }
            else { tracks.set(row, track); fireTableRowsUpdated(row, row); }
            return track;
        }
    }

    public static final class TrackTools {
        private final TrackModel model;
        public TrackTools(TrackModel model) { this.model = model; }
        @McpTool(name="list_tracks", description="Lists all tracks currently displayed in the Swing window")
        public List<Track> list() throws Exception { return onEdt(() -> new ArrayList<>(model.tracks)); }
        @McpTool(name="create_track", description="Creates a track in the Swing window. Degrees; range in nautical miles. Types: KARA, DENIZ, HAVA.")
        public Track create(@McpParam(name="trackNumber") int number,
                @McpParam(name="latitude") double lat, @McpParam(name="longitude") double lon,
                @McpParam(name="bearing") double bearing, @McpParam(name="rangeNm") double range,
                @McpParam(name="trackType") TrackType type) throws Exception {
            Track track = new Track(number, lat, lon, bearing, range, type);
            return onEdt(() -> model.save(null, track));
        }
        @McpTool(name="update_track", description="Updates an existing track and refreshes the Swing window. Supply all fields; existingTrackNumber identifies the original track.")
        public Track update(@McpParam(name="existingTrackNumber") int existing,
                @McpParam(name="trackNumber") int number, @McpParam(name="latitude") double lat,
                @McpParam(name="longitude") double lon, @McpParam(name="bearing") double bearing,
                @McpParam(name="rangeNm") double range, @McpParam(name="trackType") TrackType type) throws Exception {
            Track track = new Track(number, lat, lon, bearing, range, type);
            return onEdt(() -> model.save(existing, track));
        }
    }

    static <T> T onEdt(Callable<T> action) throws Exception {
        if (SwingUtilities.isEventDispatchThread()) return action.call();
        FutureTask<T> task = new FutureTask<>(action);
        SwingUtilities.invokeAndWait(task);
        try { return task.get(); }
        catch (java.util.concurrent.ExecutionException e) {
            if (e.getCause() instanceof Exception) throw (Exception)e.getCause();
            throw new RuntimeException(e.getCause());
        }
    }
    static String label(TrackType type) { return type == TrackType.KARA ? "Kara" : type == TrackType.DENIZ ? "Deniz" : "Hava"; }

    private static void showWindow(TrackModel model, boolean mcp) {
        JFrame frame = new JFrame("İz Yönetimi • Java 11 / Swing");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JPanel root = new JPanel(new BorderLayout(16, 16));
        root.setBorder(new EmptyBorder(22, 22, 22, 22));
        JLabel heading = new JLabel("İz Yönetimi");
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 26f));
        JPanel top = new JPanel(new BorderLayout());
        top.add(heading, BorderLayout.NORTH);
        top.add(new JLabel("Java 11 • Swing     |     " + (mcp ? "MCP: STDIO etkin" : "Yerel düzenleme") + "     |     Enlem / boylam: derece • Range: NM"), BorderLayout.SOUTH);
        root.add(top, BorderLayout.NORTH);
        JTable table = new JTable(model);
        table.setRowHeight(32);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        root.add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel editor = new JPanel(new BorderLayout(8, 12));
        editor.setBorder(BorderFactory.createTitledBorder("İz bilgileri"));
        JPanel fields = new JPanel(new GridLayout(6, 2, 10, 12));
        JTextField number = new JTextField(), lat = new JTextField(), lon = new JTextField(), bearing = new JTextField(), range = new JTextField();
        JComboBox<TrackType> type = new JComboBox<>(TrackType.values());
        type.setRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
                return super.getListCellRendererComponent(list, value instanceof TrackType ? label((TrackType)value) : value, index, selected, focus);
            }
        });
        String[] names = {"İz numarası", "Enlem (−90…90)", "Boylam (−180…180)", "Bearing (0…<360°)", "Range (NM)", "İz tipi"};
        JComponent[] inputs = {number, lat, lon, bearing, range, type};
        for (int i=0; i<names.length; i++) { fields.add(new JLabel(names[i])); fields.add(inputs[i]); }
        editor.add(fields, BorderLayout.NORTH);
        JLabel status = new JLabel("Bir iz seçerek düzenleyin veya yeni iz ekleyin.");
        final Integer[] selectedNumber = {null};
        Runnable load = () -> {
            int view = table.getSelectedRow();
            if (view < 0) return;
            Track t = model.tracks.get(table.convertRowIndexToModel(view));
            selectedNumber[0] = t.trackNumber;
            number.setText(Integer.toString(t.trackNumber)); lat.setText(Double.toString(t.latitude));
            lon.setText(Double.toString(t.longitude)); bearing.setText(Double.toString(t.bearing));
            range.setText(Double.toString(t.rangeNm)); type.setSelectedItem(t.trackType);
        };
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) load.run(); });
        model.addTableModelListener(e -> SwingUtilities.invokeLater(load));
        JButton fresh = new JButton("Yeni iz"), save = new JButton("Kaydet");
        fresh.addActionListener(e -> {
            table.clearSelection(); selectedNumber[0] = null;
            int next = 1; for (Track t : model.tracks) next = Math.max(next, t.trackNumber + 1);
            number.setText(Integer.toString(next)); lat.setText("0"); lon.setText("0"); bearing.setText("0"); range.setText("0");
            type.setSelectedItem(TrackType.KARA); status.setText("Yeni iz bilgilerini girip Kaydet'e basın."); number.requestFocusInWindow();
        });
        save.addActionListener(e -> {
            try {
                Track t = new Track(Integer.parseInt(number.getText().trim()), parse(lat), parse(lon), parse(bearing), parse(range), (TrackType)type.getSelectedItem());
                model.save(selectedNumber[0], t);
                int row = table.convertRowIndexToView(model.find(t.trackNumber));
                table.setRowSelectionInterval(row, row);
                selectedNumber[0] = t.trackNumber;
                status.setText("İz " + t.trackNumber + " kaydedildi.");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(frame, ex instanceof NumberFormatException ? "Sayısal alanları kontrol edin." : ex.getMessage(), "Geçersiz bilgi", JOptionPane.WARNING_MESSAGE);
            }
        });
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT)); buttons.add(fresh); buttons.add(save);
        editor.add(buttons, BorderLayout.SOUTH);
        root.add(editor, BorderLayout.EAST); root.add(status, BorderLayout.SOUTH);
        frame.setContentPane(root); frame.setSize(1120, 530); frame.setMinimumSize(new Dimension(930, 420));
        frame.setLocationRelativeTo(null); frame.setVisible(true);
        if (model.getRowCount() > 0) table.setRowSelectionInterval(0, 0);
    }
    private static double parse(JTextField field) { return Double.parseDouble(field.getText().trim().replace(',', '.')); }

    public static void main(String[] args) throws Exception {
        boolean mcp = java.util.Arrays.asList(args).contains("--mcp");
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        TrackModel model = new TrackModel();
        TrackTools service = new TrackTools(model);
        service.create(1001, 39.9334, 32.8597, 45, 12.5, TrackType.KARA);
        service.create(1002, 38.4237, 27.1428, 120, 24, TrackType.DENIZ);
        service.create(1003, 40.9769, 28.8146, 270, 80, TrackType.HAVA);
        onEdt(() -> { showWindow(model, mcp); return null; });
        if (mcp) {
            Gson gson = new GsonBuilder().disableHtmlEscaping().create();
            new McpServer(new JsonRpcDispatcher(gson, new ToolRegistry(gson).register(service))).runStdio();
            onEdt(() -> { for (Window w : Window.getWindows()) w.dispose(); return null; });
        }
    }
}
