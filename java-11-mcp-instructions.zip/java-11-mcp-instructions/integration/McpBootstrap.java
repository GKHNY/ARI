package integration;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.havelsan.mcp.core.ToolRegistry;
import com.havelsan.mcp.rpc.JsonRpcDispatcher;
import com.havelsan.mcp.server.McpServer;
import com.havelsan.mcp.server.McpHttpServer;
import javax.swing.SwingUtilities;

public final class McpBootstrap {
    private McpBootstrap() {}

    /** Blocking loop. Call once, outside the Swing EDT, after the window is created. */
    public static void runStdio(ExistingSwingMcpTools.TrackService existingService) throws Exception {
        if (SwingUtilities.isEventDispatchThread()) {
            throw new IllegalStateException("MCP read loop must not run on the Swing EDT");
        }
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        ToolRegistry registry = new ToolRegistry(gson)
                .register(new ExistingSwingMcpTools(existingService));
        new McpServer(new JsonRpcDispatcher(gson, registry)).runStdio();
    }
    /** Starts a local endpoint backed by the window's existing service. Close on application exit. */
    public static McpHttpServer startHttp(ExistingSwingMcpTools.TrackService existingService, int port)
            throws Exception {
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        ToolRegistry registry = new ToolRegistry(gson)
                .register(new ExistingSwingMcpTools(existingService));
        McpHttpServer server = new McpHttpServer(new JsonRpcDispatcher(gson, registry));
        server.start(port, "/mcp");
        return server;
    }
}
