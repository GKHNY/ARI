package integration;

import com.havelsan.mcp.annotation.McpParam;
import com.havelsan.mcp.annotation.McpTool;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import javax.swing.SwingUtilities;

/**
 * Adapt the existing application's service to this interface.
 * Pass the SAME model/service object used by the window, through an adapter.
 */
public final class ExistingSwingMcpTools {
    public interface TrackService {
        double getBearing(int trackNumber);
        // Must update the actual model and fire table/property change events.
        void setBearing(int trackNumber, double bearing);
    }

    private final TrackService service;
    public ExistingSwingMcpTools(TrackService service) {
        this.service = java.util.Objects.requireNonNull(service);
    }

    @McpTool(name = "get_track_bearing", description = "Reads a track bearing in degrees")
    public double getBearing(@McpParam(name = "trackNumber") int trackNumber) throws Exception {
        return onEdt(() -> service.getBearing(trackNumber));
    }

    @McpTool(name = "set_track_bearing", description = "Changes only the specified track bearing. Range: 0 inclusive to 360 exclusive.")
    public double setBearing(
            @McpParam(name = "trackNumber") int trackNumber,
            @McpParam(name = "bearing") double bearing) throws Exception {
        if (trackNumber <= 0 || !Double.isFinite(bearing) || bearing < 0 || bearing >= 360) {
            throw new IllegalArgumentException("Invalid track number or bearing");
        }
        return onEdt(() -> {
            service.setBearing(trackNumber, bearing);
            return service.getBearing(trackNumber);
        });
    }

    private static <T> T onEdt(Callable<T> action) throws Exception {
        if (SwingUtilities.isEventDispatchThread()) return action.call();
        FutureTask<T> task = new FutureTask<>(action);
        SwingUtilities.invokeAndWait(task);
        try {
            return task.get();
        } catch (ExecutionException e) {
            if (e.getCause() instanceof Exception) throw (Exception) e.getCause();
            throw new RuntimeException(e.getCause());
        }
    }
}
