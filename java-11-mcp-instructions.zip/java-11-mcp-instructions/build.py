#!/usr/bin/env python3
"""Portable Java 11 MCP library/demo builder. No network or third-party Python packages."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent

def jdk_tools():
    suffix = ".exe" if os.name == "nt" else ""
    home = os.environ.get("JAVA_HOME")
    tools = {}
    for name in ("java", "javac", "jar"):
        location = str(Path(home) / "bin" / (name + suffix)) if home else shutil.which(name)
        if not location or not Path(location).is_file():
            raise RuntimeError("JDK 11 gerekli: JAVA_HOME değerini JDK 11 klasörüne ayarlayın: " + name)
        tools[name] = location
    for name in ("java", "javac"):
        result = subprocess.run([tools[name], "-version"], capture_output=True, text=True, check=True)
        version = result.stdout + result.stderr
        import re
        if not re.search(r'(?:version\s+|javac\s+)"?11(?:[.\s"]|$)', version):
            raise RuntimeError("Bu rehber JDK 11 kullanır. JAVA_HOME ayarını kontrol edin. " + version.strip())
    return tools

def run(args):
    subprocess.run([str(x) for x in args], check=True)

def build_library(tools, source_zip, gson):
    source_zip = Path(source_zip).resolve()
    gson = Path(gson).resolve()
    if not source_zip.is_file() or not gson.is_file():
        raise RuntimeError("ZIP ve Gson JAR dosyaları mevcut olmalı.")
    lib = ROOT / "lib"
    lib.mkdir(exist_ok=True)
    target_gson = lib / "gson-2.8.0.jar"
    if gson != target_gson.resolve():
        shutil.copy2(gson, target_gson)
    packages = {"annotation", "core", "rpc", "server"}
    marker = "src/com/havelsan/mcp/"
    # Extract only Java files from the four library packages, into a temporary directory.
    with tempfile.TemporaryDirectory(prefix="java11-mcp-") as temporary:
        work = Path(temporary)
        sources = []
        with zipfile.ZipFile(source_zip) as archive:
            seen = set()
            for item in archive.infolist():
                name = item.filename.replace("\\", "/")
                if marker not in name or not name.endswith(".java"):
                    continue
                relative = name.split(marker, 1)[1]
                parts = relative.split("/")
                if len(parts) < 2 or parts[0] not in packages:
                    continue
                if any(part in ("", ".", "..") or ":" in part for part in parts):
                    raise RuntimeError("Geçersiz ZIP yolu: " + name)
                if relative in seen:
                    raise RuntimeError("Yinelenen kaynak: " + relative)
                seen.add(relative)
                target = work / "src/com/havelsan/mcp" / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(item))
                sources.append(target)
        required = {"annotation/McpTool.java", "annotation/McpParam.java",
                    "core/MethodTool.java", "core/ToolRegistry.java",
                    "rpc/JsonRpcDispatcher.java", "server/McpServer.java"}
        if not required.issubset(seen):
            raise RuntimeError("ZIP içinde beklenen MCP kaynakları eksik: " + str(required - seen))
        classes = work / "classes"
        classes.mkdir()
        run([tools["javac"], "--release", "11", "-encoding", "UTF-8", "-parameters",
             "-cp", target_gson, "-d", classes] + sorted(sources))
        run([tools["jar"], "--create", "--file", lib / "java11-mcp.jar", "-C", classes, "."])
    print("Hazır: " + str(lib / "java11-mcp.jar"), file=sys.stderr)

def build_app(tools):
    if not (ROOT / "lib/java11-mcp.jar").is_file():
        raise RuntimeError("Önce: python build.py library")
    # Compile to a clean temporary directory, then package only the demo classes.
    with tempfile.TemporaryDirectory(prefix="swing-demo-") as temporary:
        sources = sorted((ROOT / "example/src").rglob("*.java"))
        run([tools["javac"], "--release", "11", "-encoding", "UTF-8", "-parameters",
             "-cp", ROOT / "lib/*", "-d", temporary] + sources)
        (ROOT / "dist").mkdir(exist_ok=True)
        run([tools["jar"], "--create", "--file", ROOT / "dist/swing-track-demo.jar",
             "-C", temporary, "."])
    print("Hazır: " + str(ROOT / "dist/swing-track-demo.jar"), file=sys.stderr)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["library", "demo", "all", "run", "mcp"])
    parser.add_argument("--zip", default=str(ROOT / "input/java11-mcp-annotation-final.zip"))
    parser.add_argument("--gson", default=str(ROOT / "lib/gson-2.8.0.jar"))
    args = parser.parse_args()
    tools = jdk_tools()
    if args.action in ("library", "all"):
        build_library(tools, args.zip, args.gson)
    if args.action in ("demo", "all"):
        build_app(tools)
    if args.action in ("run", "mcp"):
        if not (ROOT / "dist/swing-track-demo.jar").is_file():
            raise RuntimeError("Önce: python build.py all")
        cp = os.pathsep.join([str(ROOT / "dist/swing-track-demo.jar"), str(ROOT / "lib/*")])
        command = [tools["java"], "-cp", cp, "demo.TrackApp"]
        if args.action == "mcp":
            command.append("--mcp")
        # STDIO is inherited unchanged so MCP messages reach Java directly.
        return subprocess.call(command)
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except (RuntimeError, OSError, subprocess.CalledProcessError, zipfile.BadZipFile) as error:
        print("HATA: " + str(error), file=sys.stderr)
        sys.exit(1)
