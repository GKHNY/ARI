# Mevcut Swing/OI uygulamasına minimum MCP ekleme

Hedef: Ekranda zaten bulunan ComboBox üzerinden mevcut
`setDisplayValue(JComboBox<?> combo)` metodunu **tek MCP aracıyla** tetiklemek.

Yeni pencere veya yeni model oluşturmayacağız. Mevcut pencere nesnesini MCP'ye kaydedeceğiz.
Aşağıdaki parçaları kendi sınıf ve alan adlarına uyarlamalısın; tek başına tam uygulama değildir.

## 1. İki JAR'ı projeye ekle

Paketin `lib` klasöründen:

- `java11-mcp.jar`
- `gson-2.8.0.jar`

İkisi de Java 11 uygulamanın derleme ve çalışma classpath'inde bulunmalı.
MCP kaynak kodunu uygulamanın içine kopyalaman gerekmez.

## 2. Mevcut pencere sınıfına bir tool metodu ekle

Örnekte `displayComboBox`, ekranda kullandığın mevcut `JComboBox<String>` alanıdır.
İçindeki seçeneklerin `Kara`, `Deniz`, `Hava` olduğunu varsayıyoruz.

Gerekli import'lar:

```java
import com.havelsan.mcp.annotation.McpParam;
import com.havelsan.mcp.annotation.McpTool;
import javax.swing.SwingUtilities;
```

Mevcut pencere sınıfının içine eklenecek metot:

```java
@McpTool(
    name = "set_display_value",
    description = "Ekrandaki seçimi değiştirir: Kara, Deniz veya Hava"
)
public String changeDisplay(
        @McpParam(name = "value") String value) throws Exception {

    Runnable update = () -> {
        // Gelen değer gerçekten ComboBox seçeneklerinde var mı?
        boolean found = false;
        for (int i = 0; i < displayComboBox.getItemCount(); i++) {
            if (java.util.Objects.equals(
                    value, displayComboBox.getItemAt(i))) {
                found = true;
                break;
            }
        }
        if (!found) {
            throw new IllegalArgumentException("Geçersiz seçim: " + value);
        }

        displayComboBox.setSelectedItem(value);
        setDisplayValue(displayComboBox); // Senin mevcut metodun
    };

    if (SwingUtilities.isEventDispatchThread()) {
        update.run();
    } else {
        SwingUtilities.invokeAndWait(update);
    }

    return "Seçim güncellendi: " + value;
}
```

**Seçim dinleyicisine dikkat:** ComboBox'ın ActionListener'ı zaten
`setDisplayValue` çağırıyorsa, yukarıdaki açık `setDisplayValue(displayComboBox)`
satırını kaldır. Aksi halde aynı işlem iki kez tetiklenebilir.
Bu durumda aynı değeri tekrar seçmenin beklediğin işlemi tetikleyip tetiklemediğini
uygulamanda kontrol et.

ComboBox elemanların String yerine özel nesnelerse, JSON'dan gelen ad/ID ile uygun
nesneyi bulup `setSelectedItem(oNesne)` kullan. Swing nesnesini JSON'dan almaya çalışma.

Swing işlemleri EDT üzerinde yapılır. Mevcut metot uzun ağ/veritabanı işlemi
yapıyorsa uygulamanın mevcut worker akışını kullan; uzun işi EDT üzerinde çalıştırma.

## 3. Açık pencere nesnesini MCP'ye kaydet

Başlangıç koduna gerekli import'lar:

```java
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.havelsan.mcp.core.ToolRegistry;
import com.havelsan.mcp.rpc.JsonRpcDispatcher;
import com.havelsan.mcp.server.McpHttpServer;
```

Mevcut pencere oluşturulup kullanıma hazır olduktan sonra:

```java
// existingWindow: oluşturduğun ve ekranda gösterdiğin gerçek pencere nesnesi.
// Bu noktada pencerenin Swing bileşenleri oluşturulmuş olmalı.

Gson gson = new GsonBuilder().create();

ToolRegistry registry = new ToolRegistry(gson)
        .register(existingWindow);

McpHttpServer server = new McpHttpServer(
        new JsonRpcDispatcher(gson, registry));

server.start(8765, "/mcp");
```

Bu kodu IOException'ı ele alan mevcut başlangıç metoduna ekle
(örneğin `main(...) throws Exception`). Sunucuyu bir kere başlat;
`server` referansını kapanış akışının erişebileceği bir alanda tut.

**Yeni bir pencere oluşturup register etme.** Kaydedilen nesne, kullanıcının gördüğü
pencerenin kendisi olmalı.

Bu kütüphane `getDeclaredMethods()` kullanır. Dolayısıyla annotation'lı metodun
doğrudan kaydettiğin nesnenin sınıfında tanımlı olması gerekir; yalnızca üst sınıftan
miras alınan metot bu taramada bulunmaz. Böyle bir durumda ayrı adapter kullan.

## 4. MCP'den tek tool çağrısı

İstemci `http://127.0.0.1:8765/mcp` adresine bağlanır.
Initialize ve initialized bildirimi sonrasında aşağıdaki JSON'u HTTP POST ile yollar:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "set_display_value",
    "arguments": {
      "value": "Hava"
    }
  }
}
```

Çağrı sırası:

```text
MCP: value = "Hava"
    → existingWindow.changeDisplay("Hava")
    → EDT üzerinde mevcut ComboBox'ta "Hava" seçilir
    → mevcut setDisplayValue(displayComboBox) çalışır
```

MCP'ye `JComboBox` nesnesi gönderilmez; yalnızca `"Hava"` değeri gönderilir.
Java tarafı kendi gerçek bileşen nesnesini kullanır.
ComboBox seçiminden sonra mevcut metodun model güncellemesini/kaydetmeyi yapması gerekir;
MCP eklemek otomatik olarak yeni bir kalıcılık mekanizması oluşturmaz.

Bu endpoint aynı bilgisayardaki istemciler içindir. HTTP kullanımının kapsamı ve
bağlantı adımları: [HTTP-KULLANIMI.md](HTTP-KULLANIMI.md).
Paketteki `http_client.py` iz demosunun araçlarına özeldir; bu ComboBox aracını çağırmak için
yukarıdaki tool adını ve argümanı kullanan bir istemci/HTTP isteği gerekir.

## 5. Uygulama kapanırken sunucuyu durdur

Mevcut kapanış koduna ekle:

```java
server.stop();
```

Uygulamanın veri kaydetme ve diğer kapanış adımlarını koru.

## Hızlı kontrol

1. tools/list içinde `set_display_value` görünüyor mu?
2. Hava çağrısı, zaten açık olan penceredeki seçimi değiştiriyor mu?
3. Mevcut `setDisplayValue` doğru sayıda çalışıyor mu (iki kez değil)?
4. Geçersiz bir seçenek gönderildiğinde seçim değişmeden hata geliyor mu?
5. Uygulama kapanınca HTTP portu da kapanıyor mu?
